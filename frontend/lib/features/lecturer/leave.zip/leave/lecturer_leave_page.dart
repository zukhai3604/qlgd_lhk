﻿import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'service.dart';
import 'package:qlgd_lhk/common/widgets/tlu_app_bar.dart';

class LecturerLeavePage extends StatefulWidget {
  final Map<String, dynamic> session;
  const LecturerLeavePage({super.key, required this.session});

  @override
  State<LecturerLeavePage> createState() => _LecturerLeavePageState();
}

class _LecturerLeavePageState extends State<LecturerLeavePage> {
  final _svc = LecturerLeaveService();
  final _reasonController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool _submitting = false;

  static const int _minReason = 10;
  static const int _maxReason = 500;

  @override
  void dispose() {
    _reasonController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;

    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Xác nhận gửi yêu cầu'),
        content: const Text('Bạn muốn gửi đơn xin nghỉ cho buổi học này?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Hủy')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Gửi')),
        ],
      ),
    );

    if (confirm != true) return;

    setState(() => _submitting = true);

    try {
      await _svc.submitLeaveRequest(
        scheduleId: widget.session['id'] as int,
        reason: _reasonController.text.trim(),
      );

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('✅ Gửi yêu cầu xin nghỉ thành công!')),
      );
      context.pop();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('❌ Lỗi khi gửi yêu cầu: $e')),
      );
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  // ---------- Helpers hiển thị ----------
  String _hhmm(dynamic t) {
    final s = (t ?? '').toString();
    if (s.length >= 5) return s.substring(0, 5);
    return s.isEmpty ? '--:--' : s;
    }

  String _dateVN(dynamic d) {
    final raw = (d ?? '').toString();
    if (raw.isEmpty) return '';
    final only = raw.split(' ').first; // support "yyyy-MM-dd HH:mm:ss"
    try {
      final dt = DateTime.parse(only);
      const thu = {
        1: 'Thứ 2',
        2: 'Thứ 3',
        3: 'Thứ 4',
        4: 'Thứ 5',
        5: 'Thứ 6',
        6: 'Thứ 7',
        7: 'Chủ nhật',
      };
      final dmy =
          '${dt.day.toString().padLeft(2, '0')}/${dt.month.toString().padLeft(2, '0')}/${dt.year}';
      return '${thu[dt.weekday]} • $dmy';
    } catch (_) {
      return raw;
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.session;

    final subject = (s['subject'] ?? 'Môn học').toString();
    final className = (s['class_name'] ?? '---').toString();
    var cohort = (s['cohort'] ?? '').toString().trim();
    if (cohort.isNotEmpty && !cohort.toUpperCase().startsWith('K')) cohort = 'K$cohort';
    final room = (s['room'] ?? '-').toString().trim(); // CHỈ lấy từ 'room'

    final start = _hhmm(s['start_time']);
    final end = _hhmm(s['end_time']);
    final dateLabel = _dateVN(s['date']);

    final cs = Theme.of(context).colorScheme;
    final tt = Theme.of(context).textTheme;

    return Scaffold(
      appBar: const TluAppBar(),
      body: SafeArea(
        child: GestureDetector(
          onTap: () => FocusScope.of(context).unfocus(),
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
            children: [
              // ====== CARD THÔNG TIN BUỔI HỌC (style đồng bộ) ======
              Card(
                elevation: 0,
                color: cs.surfaceVariant.withOpacity(.35),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                  side: BorderSide(color: cs.primary.withOpacity(.45), width: 1),
                ),
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(12, 12, 12, 12),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Icon tròn bên trái
                      Container(
                        width: 32,
                        height: 32,
                        decoration: BoxDecoration(
                          color: cs.primary.withOpacity(.12),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(Icons.access_time, size: 18, color: cs.primary),
                      ),
                      const SizedBox(width: 12),
                      // Nội dung
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              subject,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: tt.titleMedium?.copyWith(fontWeight: FontWeight.w700),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'Lớp: $className${cohort.isNotEmpty ? ' - $cohort' : ''} • Phòng: $room',
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: tt.bodySmall?.copyWith(color: Colors.black87),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              '$dateLabel • $start - $end',
                              style: tt.bodySmall?.copyWith(color: cs.onSurfaceVariant),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 8),
                      // Chip trạng thái (mặc định coi là sắp tới)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(
                          color: cs.primaryContainer,
                          borderRadius: BorderRadius.circular(999),
                        ),
                        child: Text(
                          'Sắp tới',
                          style: tt.labelSmall?.copyWith(
                            color: cs.onPrimaryContainer,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 20),
              Text('Lý do xin nghỉ', style: tt.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),

              // ====== FORM LÝ DO ======
              Form(
                key: _formKey,
                child: TextFormField(
                  controller: _reasonController,
                  minLines: 4,
                  maxLines: 8,
                  maxLength: _maxReason,
                  textInputAction: TextInputAction.done,
                  decoration: InputDecoration(
                    hintText: 'Nhập lý do cụ thể cho buổi xin nghỉ...',
                    helperText:
                        'Tối thiểu $_minReason ký tự • Tối đa $_maxReason ký tự',
                    border: const OutlineInputBorder(),
                    filled: true,
                    fillColor: cs.surface,
                  ),
                  validator: (v) {
                    final t = (v ?? '').trim();
                    if (t.isEmpty) return 'Vui lòng nhập lý do xin nghỉ';
                    if (t.length < _minReason) {
                      return 'Lý do quá ngắn (≥ $_minReason ký tự)';
                    }
                    return null;
                  },
                ),
              ),

              const SizedBox(height: 12),
              // Gợi ý nhanh (chips)
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  'Ốm/khám bệnh',
                  'Công tác đột xuất',
                  'Việc gia đình',
                  'Trùng lịch họp khoa'
                ]
                    .map((e) => ActionChip(
                          label: Text(e),
                          onPressed: () {
                            final cur = _reasonController.text.trim();
                            final add = e;
                            _reasonController.text =
                                (cur.isEmpty ? add : '$cur. $add');
                            _reasonController.selection = TextSelection.fromPosition(
                              TextPosition(offset: _reasonController.text.length),
                            );
                            setState(() {});
                          },
                        ))
                    .toList(),
              ),

              const SizedBox(height: 16),
              // ====== NÚT HÀNH ĐỘNG ======
              SafeArea(
                top: false,
                child: Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: _submitting ? null : () => context.pop(),
                        icon: const Icon(Icons.arrow_back),
                        label: const Text('Quay lại'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: _submitting ? null : _submit,
                        icon: _submitting
                            ? const SizedBox(
                                width: 18, height: 18,
                                child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                              )
                            : const Icon(Icons.send),
                        label: Text(_submitting ? 'Đang gửi...' : 'Gửi yêu cầu'),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

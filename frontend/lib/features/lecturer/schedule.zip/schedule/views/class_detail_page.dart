﻿// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:qlgd_lhk/common/widgets/tlu_app_bar.dart';

import '../models/schedule_item.dart';

class ClassDetailPage extends StatelessWidget {
  final ScheduleItem item;

  const ClassDetailPage({super.key, required this.item});

  @override
  Widget build(BuildContext context) {
    final fmt = DateFormat('HH:mm');
    final dateFmt = DateFormat('EEEE, dd/MM/yyyy', 'vi');
    final cs = Theme.of(context).colorScheme;

    return Scaffold(appBar: const TluAppBar(),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          _InfoCard(
            icon: Icons.book_outlined,
            title: item.subject,
            subtitle: 'Môn học',
            color: cs.primary,
          ),
          const SizedBox(height: 12),
          _InfoCard(
            icon: Icons.group_outlined,
            title: item.className,
            subtitle: 'Lớp học',
            color: cs.secondary,
          ),
          const SizedBox(height: 12),
          _InfoCard(
            icon: Icons.meeting_room_outlined,
            title: item.room.isEmpty ? 'Chưa cập nhật' : item.room,
            subtitle: 'Phòng học',
            color: cs.tertiary,
          ),
          const SizedBox(height: 20),
          Card(
            elevation: 1,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    dateFmt.format(item.startTime),
                    style: Theme.of(context)
                        .textTheme
                        .titleMedium
                        ?.copyWith(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      const Icon(Icons.schedule, size: 18),
                      const SizedBox(width: 6),
                      Text(
                          '${fmt.format(item.startTime)} - ${fmt.format(item.endTime)}'),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      const Icon(Icons.info_outline, size: 18),
                      const SizedBox(width: 6),
                      Text(item.statusLabel()),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),
          _RawDebugSection(raw: item.raw),
        ],
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;

  const _InfoCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 1,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: color.withOpacity(0.15),
          child: Icon(icon, color: color),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(subtitle),
      ),
    );
  }
}

class _RawDebugSection extends StatelessWidget {
  final Map<String, dynamic> raw;

  const _RawDebugSection({required this.raw});

  @override
  Widget build(BuildContext context) {
    return ExpansionTile(
      title: const Text('Dữ liệu gốc'),
      subtitle: const Text('Phục vụ debug nhanh'),
      children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surfaceVariant.withOpacity(.4),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Text(
            raw.toString(),
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ),
      ],
    );
  }
}







// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'attendance_dto.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

AttendanceDto _$AttendanceDtoFromJson(Map<String, dynamic> json) {
  return _AttendanceDto.fromJson(json);
}

/// @nodoc
mixin _$AttendanceDto {
  String get id => throw _privateConstructorUsedError;
  String get studentId => throw _privateConstructorUsedError;
  String get scheduleId => throw _privateConstructorUsedError;
  bool get isPresent => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $AttendanceDtoCopyWith<AttendanceDto> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $AttendanceDtoCopyWith<$Res> {
  factory $AttendanceDtoCopyWith(
          AttendanceDto value, $Res Function(AttendanceDto) then) =
      _$AttendanceDtoCopyWithImpl<$Res, AttendanceDto>;
  @useResult
  $Res call({String id, String studentId, String scheduleId, bool isPresent});
}

/// @nodoc
class _$AttendanceDtoCopyWithImpl<$Res, $Val extends AttendanceDto>
    implements $AttendanceDtoCopyWith<$Res> {
  _$AttendanceDtoCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? studentId = null,
    Object? scheduleId = null,
    Object? isPresent = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      studentId: null == studentId
          ? _value.studentId
          : studentId // ignore: cast_nullable_to_non_nullable
              as String,
      scheduleId: null == scheduleId
          ? _value.scheduleId
          : scheduleId // ignore: cast_nullable_to_non_nullable
              as String,
      isPresent: null == isPresent
          ? _value.isPresent
          : isPresent // ignore: cast_nullable_to_non_nullable
              as bool,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$AttendanceDtoImplCopyWith<$Res>
    implements $AttendanceDtoCopyWith<$Res> {
  factory _$$AttendanceDtoImplCopyWith(
          _$AttendanceDtoImpl value, $Res Function(_$AttendanceDtoImpl) then) =
      __$$AttendanceDtoImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String id, String studentId, String scheduleId, bool isPresent});
}

/// @nodoc
class __$$AttendanceDtoImplCopyWithImpl<$Res>
    extends _$AttendanceDtoCopyWithImpl<$Res, _$AttendanceDtoImpl>
    implements _$$AttendanceDtoImplCopyWith<$Res> {
  __$$AttendanceDtoImplCopyWithImpl(
      _$AttendanceDtoImpl _value, $Res Function(_$AttendanceDtoImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? studentId = null,
    Object? scheduleId = null,
    Object? isPresent = null,
  }) {
    return _then(_$AttendanceDtoImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      studentId: null == studentId
          ? _value.studentId
          : studentId // ignore: cast_nullable_to_non_nullable
              as String,
      scheduleId: null == scheduleId
          ? _value.scheduleId
          : scheduleId // ignore: cast_nullable_to_non_nullable
              as String,
      isPresent: null == isPresent
          ? _value.isPresent
          : isPresent // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$AttendanceDtoImpl implements _AttendanceDto {
  const _$AttendanceDtoImpl(
      {required this.id,
      required this.studentId,
      required this.scheduleId,
      required this.isPresent});

  factory _$AttendanceDtoImpl.fromJson(Map<String, dynamic> json) =>
      _$$AttendanceDtoImplFromJson(json);

  @override
  final String id;
  @override
  final String studentId;
  @override
  final String scheduleId;
  @override
  final bool isPresent;

  @override
  String toString() {
    return 'AttendanceDto(id: $id, studentId: $studentId, scheduleId: $scheduleId, isPresent: $isPresent)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$AttendanceDtoImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.studentId, studentId) ||
                other.studentId == studentId) &&
            (identical(other.scheduleId, scheduleId) ||
                other.scheduleId == scheduleId) &&
            (identical(other.isPresent, isPresent) ||
                other.isPresent == isPresent));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode =>
      Object.hash(runtimeType, id, studentId, scheduleId, isPresent);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$AttendanceDtoImplCopyWith<_$AttendanceDtoImpl> get copyWith =>
      __$$AttendanceDtoImplCopyWithImpl<_$AttendanceDtoImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$AttendanceDtoImplToJson(
      this,
    );
  }
}

abstract class _AttendanceDto implements AttendanceDto {
  const factory _AttendanceDto(
      {required final String id,
      required final String studentId,
      required final String scheduleId,
      required final bool isPresent}) = _$AttendanceDtoImpl;

  factory _AttendanceDto.fromJson(Map<String, dynamic> json) =
      _$AttendanceDtoImpl.fromJson;

  @override
  String get id;
  @override
  String get studentId;
  @override
  String get scheduleId;
  @override
  bool get isPresent;
  @override
  @JsonKey(ignore: true)
  _$$AttendanceDtoImplCopyWith<_$AttendanceDtoImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

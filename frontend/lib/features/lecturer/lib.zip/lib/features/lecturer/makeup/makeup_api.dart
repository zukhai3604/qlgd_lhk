// ignore_for_file: deprecated_member_use
import 'package:dio/dio.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:dio/browser.dart' if (dart.library.io) 'package:dio/adapter.dart';

class LecturerMakeupApi {
  final Dio _dio;

  LecturerMakeupApi({Dio? dio})
      : _dio = dio ??
      Dio(
        BaseOptions(
          baseUrl: const String.fromEnvironment(
            'BASE_URL',
            defaultValue: 'http://127.0.0.1:8000',
          ),
          connectTimeout: const Duration(seconds: 8),
          receiveTimeout: const Duration(seconds: 15),
          headers: const {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
          },
        ),
      ) {
    try {
      final adapter = BrowserHttpClientAdapter();
      adapter.withCredentials = false;
      _dio.httpClientAdapter = adapter;
    } catch (_) {}

    _dio.interceptors.add(
      InterceptorsWrapper(
        onRequest: (options, handler) async {
          try {
            const storage = FlutterSecureStorage();
            final token = await storage.read(key: 'access_token') ??
                await storage.read(key: 'auth_token');
            if (token != null && token.isNotEmpty) {
              options.headers['Authorization'] = 'Bearer $token';
            }
          } catch (_) {}
          handler.next(options);
        },
      ),
    );
  }

  // ALWAYS return a mutable list
  List<Map<String, dynamic>> _asList(dynamic data) {
    if (data is List) {
      return data.map((e) => Map<String, dynamic>.from(e as Map)).toList();
    }
    if (data is Map && data['data'] is List) {
      return (data['data'] as List)
          .map((e) => Map<String, dynamic>.from(e as Map))
          .toList();
    }
    return []; // <<== not const
  }

  Future<List<Map<String, dynamic>>> list({String? status}) async {
    final res = await _dio.get(
      '/api/lecturer/makeup-requests',
      queryParameters: {if (status != null && status.isNotEmpty) 'status': status},
    );
    return _asList(res.data);
  }

  Future<Map<String, dynamic>> create(Map<String, dynamic> payload) async {
    final res = await _dio.post('/api/lecturer/makeup-requests', data: payload);
    return Map<String, dynamic>.from(res.data as Map);
  }

  Future<void> cancel(int id) async {
    await _dio.delete('/api/lecturer/makeup-requests/$id');
  }

  Future<Map<String, dynamic>> detail(int id) async {
    final res = await _dio.get('/api/lecturer/makeup-requests/$id');
    return Map<String, dynamic>.from(res.data as Map);
  }

  Future<List<Map<String, dynamic>>> approvedLeaves({int page = 1}) async {
    try {
      final r = await _dio.get(
        '/api/lecturer/leave-requests',
        queryParameters: {'status': 'APPROVED', 'page': page},
      );
      final list = _asList(r.data);
      if (list.isNotEmpty) return list;
    } catch (_) {}

    for (final path in const [
      '/api/lecturer/approved-leaves',
      '/api/lecturer/leaves',
      '/api/lecturer/leave',
    ]) {
      try {
        final r = await _dio.get(path, queryParameters: {'status': 'APPROVED', 'page': page});
        final list = _asList(r.data);
        if (list.isNotEmpty) return list;
      } catch (_) {}
    }

    try {
      final r = await _dio.get(
        '/api/lecturer/makeup-requests',
        queryParameters: {'status': 'APPROVED', 'page': page},
      );
      return _asList(r.data);
    } catch (_) {
      return []; // <<== not const
    }
  }
}

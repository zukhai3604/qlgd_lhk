// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:go_router/go_router.dart';

import 'package:qlgd_lhk/common/widgets/tlu_app_bar.dart';
import '../schedule/service.dart';
import 'makeup_api.dart';

class LecturerMakeupPage extends StatefulWidget {
  const LecturerMakeupPage({super.key, required this.contextData});
  // contextData push từ Leave History:
  // {'id': schedule_id, 'leave_request_id': ..., 'subjectName': ..., 'date': 'dd/MM/yyyy', 'timeSlot': 'HH:mm - HH:mm', 'reason': ...}
  final Map<String, dynamic> contextData;

  @override
  State<LecturerMakeupPage> createState() => _LecturerMakeupPageState();
}

class _LecturerMakeupPageState extends State<LecturerMakeupPage> {
  final _formKey = GlobalKey<FormState>();
  final _dateCtrl = TextEditingController();
  final _startCtrl = TextEditingController();
  final _endCtrl = TextEditingController();
  final _roomCtrl = TextEditingController();
  final _noteCtrl = TextEditingController();

  final _scheduleSvc = LecturerScheduleService();
  bool _loadingInfo = true;
  Map<String, dynamic> _sd = const {}; // schedule detail (nếu lấy được)

  bool _submitting = false;

  @override
  void initState() {
    super.initState();
    // Gợi ý giờ từ contextData
    final ts = (widget.contextData['timeSlot'] ?? '').toString();
    final parts = ts.split('-').map((e) => e.trim()).toList();
    if (parts.length == 2) {
      _startCtrl.text = _hhmm(parts[0]);
      _endCtrl.text = _hhmm(parts[1]);
    }
    _loadDetail();
  }

  Future<void> _loadDetail() async {
    setState(() => _loadingInfo = true);
    try {
      final id = int.tryParse('${widget.contextData['id']}');
      if (id != null) {
        final raw = await _scheduleSvc.getDetail(id);
        _sd = Map<String, dynamic>.from(raw);
      }
    } catch (_) {
      _sd = const {};
    } finally {
      if (mounted) setState(() => _loadingInfo = false);
    }
  }

  @override
  void dispose() {
    _dateCtrl.dispose();
    _startCtrl.dispose();
    _endCtrl.dispose();
    _roomCtrl.dispose();
    _noteCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: now,
      firstDate: now,
      lastDate: now.add(const Duration(days: 180)),
      locale: const Locale('vi', 'VN'),
    );
    if (picked != null) {
      _dateCtrl.text = DateFormat('dd/MM/yyyy').format(picked);
    }
  }

  Future<void> _pickTime(TextEditingController ctrl) async {
    final now = TimeOfDay.now();
    final t = await showTimePicker(context: context, initialTime: now, helpText: 'Chọn thời gian');
    if (t != null) ctrl.text = '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';
  }

  String _hhmm(String raw) {
    final s = raw.trim();
    if (s.contains('T')) {
      try {
        final dt = DateTime.parse(s);
        return DateFormat('HH:mm').format(dt);
      } catch (_) {}
    }
    final parts = s.split(':');
    if (parts.length >= 2) return '${parts[0].padLeft(2, '0')}:${parts[1].padLeft(2, '0')}';
    return s;
  }

  String _toIsoDate(String ddMMyyyy) {
    try {
      final dt = DateFormat('dd/MM/yyyy').parseStrict(ddMMyyyy);
      return DateFormat('yyyy-MM-dd').format(dt);
    } catch (_) {
      return ddMMyyyy;
    }
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _submitting = true);
    try {
      final api = LecturerMakeupApi();
      final payload = {
        'leave_request_id': widget.contextData['leave_request_id'],
        'schedule_id': widget.contextData['id'],
        'makeup_date': _toIsoDate(_dateCtrl.text.trim()),
        'start_time': _startCtrl.text.trim(),
        'end_time': _endCtrl.text.trim(),
        'room': _roomCtrl.text.trim(),
        'note': _noteCtrl.text.trim(),
      };
      await api.create(payload);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Đã gửi lịch dạy bù.')));
        context.go('/makeup/history');
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Gửi thất bại: $e')));
      }
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  // ------------------------ Extractors (giống Leave) ------------------------

  String _pickStr(Map data, List<String> paths) {
    for (final p in paths) {
      dynamic cur = data;
      for (final seg in p.split('.')) {
        if (cur is Map && cur.containsKey(seg)) cur = cur[seg];
        else { cur = null; break; }
      }
      if (cur != null && cur.toString().trim().isNotEmpty) return cur.toString().trim();
    }
    return '';
  }

  String _subject() {
    // Ưu tiên từ schedule detail
    final fromSd = _pickStr(_sd, [
      'assignment.subject.name','assignment.subject.title','subject.name','subject.title','subject_name','subject','course_name','title',
    ]);
    if (fromSd.isNotEmpty) return fromSd;
    // Fallback từ contextData
    final fromCtx = (widget.contextData['subjectName'] ?? '').toString().trim();
    return fromCtx.isNotEmpty ? fromCtx : 'Môn học';
  }

  String _className() {
    final fromSd = _pickStr(_sd, [
      'assignment.class_unit.name','assignment.class_unit.code',
      'assignment.classUnit.name','assignment.classUnit.code',
      'class_unit.name','class_unit.code',
      'class_name','class','class_code','group_name',
    ]);
    if (fromSd.isNotEmpty) return fromSd;
    // contextData hiện chưa truyền class_name, nên để rỗng nếu không có
    return (widget.contextData['class_name'] ?? '').toString();
  }

  String _cohort() {
    var c = _pickStr(_sd, ['cohort','k','course','batch']);
    if (c.isNotEmpty && !c.toUpperCase().startsWith('K')) c = 'K$c';
    return c;
  }

  String _room() {
    // object room
    if (_sd['room'] is Map) {
      final r = _sd['room'] as Map;
      final code = _pickStr(r, ['code','name','room_code','title','label']);
      if (code.isNotEmpty) return code;
    }
    // string room
    if (_sd['room'] is String && (_sd['room'] as String).trim().isNotEmpty) {
      return (_sd['room'] as String).trim();
    }
    // assignment.room
    if (_sd['assignment'] is Map && (_sd['assignment'] as Map)['room'] is Map) {
      final r = (_sd['assignment'] as Map)['room'] as Map;
      final code = _pickStr(r, ['code','name','room_code','title','label']);
      if (code.isNotEmpty) return code;
    }
    // list rooms
    final rooms = _sd['rooms'] ?? _sd['classrooms'] ?? _sd['room_list'];
    if (rooms is List && rooms.isNotEmpty) {
      final first = rooms.first;
      if (first is String && first.trim().isNotEmpty) return first.trim();
      if (first is Map) {
        final code = _pickStr(first, ['code','name','room_code','title','label']);
        if (code.isNotEmpty) return code;
      }
    }
    // building + number
    final building = _pickStr(_sd, ['building','building.name','block','block.name']);
    final num = _pickStr(_sd, ['room_number','roomNo','room_no','code','room_code']);
    if (building.isNotEmpty && num.isNotEmpty) return '$building-$num';
    if (num.isNotEmpty) return num;

    // cuối cùng: nếu contextData có 'room'
    return (widget.contextData['room'] ?? '').toString();
  }

  String _dateVN() {
    // từ schedule detail
    final iso = _pickStr(_sd, ['session_date','date','timeslot.date','period.date','start_at']);
    if (iso.isNotEmpty) {
      final only = iso.split(' ').first;
      try {
        final dt = DateTime.parse(only);
        return DateFormat('EEEE, dd/MM/yyyy', 'vi_VN').format(dt);
      } catch (_) {}
    }
    // fallback contextData['date'] (đã là dd/MM/yyyy)
    final d = (widget.contextData['date'] ?? '').toString();
    return d;
  }

  String _startStr() {
    final raw = _pickStr(_sd, ['timeslot.start_time','timeslot.start','start_time','startTime','slot.start']);
    if (raw.isNotEmpty) return _hhmm(raw);
    // fallback từ contextData timeSlot
    final ts = (widget.contextData['timeSlot'] ?? '').toString();
    final p = ts.split('-').map((e) => e.trim()).toList();
    return p.isNotEmpty ? _hhmm(p.first) : '';
  }

  String _endStr() {
    final raw = _pickStr(_sd, ['timeslot.end_time','timeslot.end','end_time','endTime','slot.end']);
    if (raw.isNotEmpty) return _hhmm(raw);
    final ts = (widget.contextData['timeSlot'] ?? '').toString();
    final p = ts.split('-').map((e) => e.trim()).toList();
    return p.length == 2 ? _hhmm(p.last) : '';
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final c = widget.contextData;
    final reason = (c['reason'] ?? '').toString();

    final subject = _subject();
    final className = _className();
    final cohort = _cohort();
    final room = _room();
    final dateLabel = _dateVN();
    final start = _startStr();
    final end = _endStr();

    return Scaffold(
      appBar: const TluAppBar(title: 'Đăng ký dạy bù'),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // ===== Card thông tin buổi học (giống Leave) =====
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: _loadingInfo
                  ? const SizedBox(height: 24, child: Center(child: CircularProgressIndicator(strokeWidth: 2)))
                  : DefaultTextStyle.merge(
                style: const TextStyle(fontSize: 14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(subject, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                    const SizedBox(height: 6),
                    Text([
                      if (className.isNotEmpty) 'Lớp: $className',
                      if (cohort.isNotEmpty) cohort,
                      if (room.isNotEmpty) '• Phòng: $room',
                    ].where((e) => e.isNotEmpty).join(' - ').replaceAll(' - •', ' •')),
                    const SizedBox(height: 4),
                    Text([
                      if (dateLabel.isNotEmpty) dateLabel,
                      if (start.isNotEmpty || end.isNotEmpty) '${start.isNotEmpty ? start : '--:--'} - ${end.isNotEmpty ? end : '--:--'}',
                    ].where((e) => e.isNotEmpty).join(' • ')),
                    if (reason.isNotEmpty) ...[
                      const SizedBox(height: 6),
                      Text('Lý do nghỉ: $reason'),
                    ],
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),

          // ===== Form đăng ký dạy bù =====
          Form(
            key: _formKey,
            child: Column(
              children: [
                // Ngày dạy bù
                TextFormField(
                  controller: _dateCtrl,
                  readOnly: true,
                  decoration: InputDecoration(
                    labelText: 'Ngày dạy bù',
                    hintText: 'dd/MM/yyyy',
                    border: const OutlineInputBorder(),
                    suffixIcon: IconButton(icon: const Icon(Icons.event), onPressed: _pickDate),
                  ),
                  validator: (v) => (v == null || v.trim().isEmpty) ? 'Chọn ngày dạy bù' : null,
                ),
                const SizedBox(height: 12),

                // Giờ bắt đầu
                TextFormField(
                  controller: _startCtrl,
                  readOnly: true,
                  decoration: InputDecoration(
                    labelText: 'Giờ bắt đầu',
                    hintText: 'HH:mm',
                    border: const OutlineInputBorder(),
                    suffixIcon: IconButton(icon: const Icon(Icons.schedule), onPressed: () => _pickTime(_startCtrl)),
                  ),
                  validator: (v) => (v == null || v.trim().isEmpty) ? 'Chọn giờ bắt đầu' : null,
                ),
                const SizedBox(height: 12),

                // Giờ kết thúc
                TextFormField(
                  controller: _endCtrl,
                  readOnly: true,
                  decoration: InputDecoration(
                    labelText: 'Giờ kết thúc',
                    hintText: 'HH:mm',
                    border: const OutlineInputBorder(),
                    suffixIcon: IconButton(icon: const Icon(Icons.schedule), onPressed: () => _pickTime(_endCtrl)),
                  ),
                  validator: (v) => (v == null || v.trim().isEmpty) ? 'Chọn giờ kết thúc' : null,
                ),
                const SizedBox(height: 12),

                // Phòng
                TextFormField(
                  controller: _roomCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Phòng học',
                    hintText: 'VD: 204-A2',
                    border: OutlineInputBorder(),
                  ),
                  validator: (v) => (v == null || v.trim().isEmpty) ? 'Nhập phòng' : null,
                ),
                const SizedBox(height: 12),

                // Ghi chú
                TextFormField(
                  controller: _noteCtrl,
                  maxLines: 3,
                  decoration: const InputDecoration(
                    labelText: 'Ghi chú (tuỳ chọn)',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 16),

                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: _submitting ? null : _submit,
                    icon: _submitting
                        ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                        : const Icon(Icons.send),
                    label: const Text('Gửi đăng ký dạy bù'),
                  ),
                ),
                const SizedBox(height: 8),

                TextButton.icon(
                  onPressed: () => context.go('/makeup/history'),
                  icon: const Icon(Icons.history),
                  label: const Text('Xem lịch sử dạy bù'),
                  style: TextButton.styleFrom(foregroundColor: cs.primary),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

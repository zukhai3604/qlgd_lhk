// ignore_for_file: deprecated_member_use
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'makeup_api.dart';

class LecturerMakeupHistoryPage extends StatefulWidget {
  const LecturerMakeupHistoryPage({super.key});
  @override
  State<LecturerMakeupHistoryPage> createState() => _LecturerMakeupHistoryPageState();
}

class _LecturerMakeupHistoryPageState extends State<LecturerMakeupHistoryPage> {
  final _api = LecturerMakeupApi();
  bool _loading = true;
  String? _error;
  List<Map<String, dynamic>> _items = const [];

  @override
  void initState() { super.initState(); _fetch(); }

  Future<void> _fetch() async {
    setState(() => _loading = true);
    try {
      final list = await _api.list(); // tất cả đơn dạy bù
      _items = list;
      _error = null;
    } catch (e) {
      _error = 'Không tải được lịch sử dạy bù: $e';
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  String _hhmm(String? t) {
    if (t == null || t.isEmpty) return '--:--';
    final parts = t.split(':');
    if (parts.length >= 2) return '${parts[0].padLeft(2,'0')}:${parts[1].padLeft(2,'0')}';
    return t;
  }

  String _ddmmyyyy(String? iso) {
    if (iso == null || iso.isEmpty) return '';
    final raw = iso.length >= 10 ? iso.substring(0,10) : iso;
    try { return DateFormat('dd/MM/yyyy').format(DateTime.parse(raw)); } catch (_) { return iso; }
  }

  ({String label, Color color}) _st(String s) {
    switch ((s).toUpperCase()) {
      case 'APPROVED': return (label:'Đã duyệt', color: Colors.green);
      case 'REJECTED': return (label:'Từ chối', color: Colors.red);
      case 'PENDING' : return (label:'Chờ duyệt', color: Colors.orange);
      case 'CANCELED': return (label:'Đã hủy', color: Colors.grey);
      default: return (label: s, color: Colors.blueGrey);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (_error != null) return Scaffold(body: Center(child: Text(_error!)));

    return Scaffold(
      appBar: AppBar(title: const Text('Lịch sử đăng ký dạy bù')),
      body: RefreshIndicator(
        onRefresh: _fetch,
        child: _items.isEmpty
            ? ListView(children: const [SizedBox(height: 200), Center(child: Text('Chưa có đơn dạy bù.'))])
            : ListView.builder(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
          itemCount: _items.length,
          itemBuilder: (_, i) {
            final it = _items[i];
            final subject = (it['subject'] ?? it['subject_name'] ?? it['title'] ?? 'Môn học').toString();
            final date = _ddmmyyyy(it['makeup_date']?.toString());
            final tr = '${_hhmm(it['start_time']?.toString())} - ${_hhmm(it['end_time']?.toString())}';
            final room = (it['room'] ?? '').toString();
            final status = _st((it['status'] ?? 'PENDING').toString());

            final line = [
              if (date.isNotEmpty) date,
              tr,
              if (room.isNotEmpty) 'Phòng: $room'
            ].join(' · ');

            return Card(
              margin: const EdgeInsets.only(bottom: 10),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
                side: BorderSide(color: status.color.withOpacity(.5)),
              ),
              child: ListTile(
                title: Text(subject, style: const TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text(line),
                trailing: Chip(
                  label: Text(status.label, style: const TextStyle(fontSize: 10)),
                  backgroundColor: status.color.withOpacity(.15),
                  side: BorderSide.none,
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

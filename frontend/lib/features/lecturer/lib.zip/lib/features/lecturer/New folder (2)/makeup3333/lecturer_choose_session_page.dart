// ignore_for_file: deprecated_member_use
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import 'package:qlgd_lhk/common/widgets/tlu_app_bar.dart';
import 'makeup_api.dart';

class LecturerChooseSessionPage extends StatefulWidget {
  const LecturerChooseSessionPage({super.key});

  @override
  State<LecturerChooseSessionPage> createState() => _LecturerChooseSessionPageState();
}

class _LecturerChooseSessionPageState extends State<LecturerChooseSessionPage> {
  final _api = LecturerMakeupApi();

  bool loading = true;
  String? error;
  List<Map<String, dynamic>> leaves = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    if (!mounted) return;
    setState(() {
      loading = true;
      error = null;
    });

    try {
      // 1) Lấy danh sách; luôn clone -> list growable + map mutable
      final raw = await _api.approvedLeaves(page: 1);
      final list = raw
          .map((e) => Map<String, dynamic>.from(e)) // cho phép thêm field phụ
          .toList(growable: true);                  // cho phép sort()

      // 2) Chuẩn hoá __date__ để sort
      for (final e in list) {
        final rawDate = (e['date'] ?? e['leave_date'] ?? e['session_date'])?.toString();
        e['__date__'] = (rawDate != null && rawDate.length >= 10) ? rawDate.substring(0, 10) : '';
      }

      // 3) Sort an toàn (tránh "Unsupported operation: sort")
      if (list.length > 1) {
        list.sort((a, b) {
          final da = DateTime.tryParse('${a['__date__']}') ?? DateTime(2100);
          final db = DateTime.tryParse('${b['__date__']}') ?? DateTime(2100);
          return da.compareTo(db);
        });
      }

      if (mounted) setState(() => leaves = list);
    } catch (e) {
      if (mounted) setState(() => error = 'Không tải được buổi nghỉ đã duyệt: $e');
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: const TluAppBar(),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : error != null
          ? _ErrorBox(message: error!, onRetry: _load)
          : RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
          children: [
            const SizedBox(height: 4),
            Row(
              children: [
                Expanded(
                  child: Text(
                    'Chọn buổi nghỉ để đăng ký dạy bù',
                    style: Theme.of(context)
                        .textTheme
                        .titleLarge
                        ?.copyWith(fontWeight: FontWeight.w800),
                  ),
                ),
                OutlinedButton.icon(
                  onPressed: () => context.push('/lecturer/makeup/history'),
                  icon: const Icon(Icons.history),
                  label: const Text('Lịch sử đăng ký'),
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
                    side: BorderSide(color: cs.primary),
                    foregroundColor: cs.primary,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),

            if (leaves.isEmpty)
              const _EmptyBox(text: 'Chưa có buổi nghỉ đã duyệt. Kéo xuống để tải lại.')
            else
              ...leaves.map(
                    (s) => _LeaveItemTile(
                  data: s,
                  onTap: () => context.push('/lecturer/makeup/form', extra: s),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

/* ----------------------- Item + helpers + boxes ----------------------- */

class _LeaveItemTile extends StatelessWidget {
  final Map<String, dynamic> data;
  final VoidCallback onTap;
  const _LeaveItemTile({super.key, required this.data, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    final subject = _subjectOf(data);
    final className = _classNameOf(data);
    final cohort = _cohortOf(data);
    final room = _roomOf(data);

    // "Lớp: {class} - K.. • Phòng: .."
    final left = [
      if (className.isNotEmpty) 'Lớp: $className',
      if (cohort.isNotEmpty) cohort,
      if (room.isNotEmpty) '• Phòng: $room',
    ].where((e) => e.isNotEmpty).join(' - ').replaceAll(' - •', ' •');

    // Ngày & thời gian
    final dateStr = (data['__date__'] ?? data['date'] ?? data['leave_date'])?.toString();
    final dateLabel = _dateVN(dateStr);
    final timeRange = _timeRangeOf(data);
    final timeline = [
      if (dateLabel.isNotEmpty) dateLabel,
      if (timeRange != '--:-- - --:--') timeRange,
    ].join(' • ');

    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 10),
      color: cs.surfaceVariant.withOpacity(.35),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: cs.primary.withOpacity(.45), width: 1),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // icon
              Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(color: cs.primary.withOpacity(.12), shape: BoxShape.circle),
                child: Icon(Icons.event_busy, size: 18, color: cs.primary),
              ),
              const SizedBox(width: 12),

              // content
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      subject,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700),
                    ),
                    const SizedBox(height: 4),
                    if (left.isNotEmpty)
                      Text(
                        left,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Colors.black54),
                      ),
                    const SizedBox(height: 6),
                    Text(timeline, style: Theme.of(context).textTheme.bodySmall),
                  ],
                ),
              ),

              const SizedBox(width: 8),

              // actions
              FilledButton.icon(
                onPressed: onTap,
                icon: const Icon(Icons.add),
                label: const Text('Đăng ký dạy bù'),
                style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8)),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(color: cs.primaryContainer, borderRadius: BorderRadius.circular(999)),
                child: Text(
                  'Đã duyệt nghỉ',
                  style: Theme.of(context)
                      .textTheme
                      .labelSmall
                      ?.copyWith(color: cs.onPrimaryContainer, fontWeight: FontWeight.w700),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/* ---------------------------- Robust helpers ---------------------------- */

// Lấy theo danh sách keys; hỗ trợ key dạng "a.b.c"
String _pick(Map s, List<String> keys, {String def = ''}) {
  for (final k in keys) {
    final v = _pickPath(s, k);
    if (v != null && v.toString().trim().isNotEmpty) {
      return v.toString().trim();
    }
  }
  return def;
}

// Lấy theo path "a.b.c"
dynamic _pickPath(Map s, String path) {
  dynamic cur = s;
  for (final seg in path.split('.')) {
    if (cur is Map && cur.containsKey(seg)) {
      cur = cur[seg];
    } else {
      return null;
    }
  }
  return cur;
}

String _pickObj(Map? obj, List<String> keys, {String def = ''}) {
  if (obj == null) return def;
  for (final k in keys) {
    final v = obj[k];
    if (v != null && v.toString().trim().isNotEmpty) return v.toString().trim();
  }
  return def;
}

String _subjectOf(Map<String, dynamic> s) {
  final v = _pick(s, [
    'subject',
    'subject_name',
    'course_name',
    'title',
    'assignment.subject.name',
    'assignment.subject.title',
  ]);
  return v.isNotEmpty ? v : 'Môn học';
}

String _classNameOf(Map<String, dynamic> s) {
  // Ưu tiên flat
  var v = _pick(s, ['class_name', 'class', 'class_code', 'group_name']);
  if (v.isNotEmpty) return v;

  // assignment.class_unit / classUnit
  final a = _pickPath(s, 'assignment');
  if (a is Map) {
    v = _pickObj(a['class_unit'] as Map?, ['name', 'code']);
    if (v.isNotEmpty) return v;
    v = _pickObj(a['classUnit'] as Map?, ['name', 'code']);
    if (v.isNotEmpty) return v;
  }
  return v;
}

String _cohortOf(Map<String, dynamic> s) {
  var c = _pick(s, ['cohort', 'k', 'course', 'batch']);
  if (c.isNotEmpty && !c.toUpperCase().startsWith('K')) c = 'K$c';
  return c;
}

String _roomOf(Map<String, dynamic> s) {
  // 1) room là object
  final roomObj = _pickPath(s, 'room');
  if (roomObj is Map) {
    final code = _pickObj(roomObj, ['code', 'name', 'room_code', 'title', 'label']);
    if (code.isNotEmpty) return code;
  }

  // 2) room là chuỗi
  final roomStr = _pick(s, ['room']);
  if (roomStr.isNotEmpty) return roomStr;

  // 3) trong assignment
  final a = _pickPath(s, 'assignment');
  if (a is Map && a['room'] is Map) {
    final code = _pickObj(a['room'] as Map, ['code', 'name', 'room_code', 'title', 'label']);
    if (code.isNotEmpty) return code;
  }

  // 4) từ danh sách
  final rooms = _pickPath(s, 'rooms') ?? _pickPath(s, 'classrooms') ?? _pickPath(s, 'room_list');
  if (rooms is List && rooms.isNotEmpty) {
    final first = rooms.first;
    if (first is String && first.trim().isNotEmpty) return first.trim();
    if (first is Map) {
      final code = _pickObj(first, ['code', 'name', 'room_code', 'title', 'label']);
      if (code.isNotEmpty) return code;
    }
  }

  // 5) building + number
  final building = _pick(s, ['building', 'building.name', 'block', 'block.name']);
  final num = _pick(s, ['room_number', 'roomNo', 'room_no', 'code', 'room_code']);
  if (building.isNotEmpty && num.isNotEmpty) return '$building-$num';
  if (num.isNotEmpty) return num;

  // 6) fallback các key hay đính kèm trong leave
  final fromLeave = _pick(s, ['room_code', 'roomName']);
  return fromLeave;
}

String _hhmm(String? raw) {
  if (raw == null || raw.isEmpty) return '--:--';
  final s = raw.trim();
  if (s.contains('T')) {
    try {
      final dt = DateTime.parse(s);
      return DateFormat('HH:mm').format(dt);
    } catch (_) {}
  }
  final parts = s.split(':');
  if (parts.length >= 2) return '${parts[0].padLeft(2, '0')}:${parts[1].padLeft(2, '0')}';
  return s;
}

String _timeRangeOf(Map<String, dynamic> s) {
  // Nếu có field đã gộp
  final times = _pick(s, ['times', 'timespan']);
  if (times.isNotEmpty) {
    final parts = times.split('-').map((e) => e.trim()).toList();
    if (parts.length == 2) return '${_hhmm(parts[0])} - ${_hhmm(parts[1])}';
    return times;
  }

  // Từ start_time / end_time hoặc biến thể
  final st = _pick(s, ['start_time', 'startTime', 'timeslot.start', 'period.start', 'slot.start']);
  final et = _pick(s, ['end_time', 'endTime', 'timeslot.end', 'period.end', 'slot.end']);
  final left = _hhmm(st);
  final right = _hhmm(et);
  return '$left - $right';
}

String _dateVN(String? isoOrDate) {
  if (isoOrDate == null || isoOrDate.isEmpty) return '';
  final raw = isoOrDate.length >= 10 ? isoOrDate.substring(0, 10) : isoOrDate;
  try {
    final dt = DateTime.parse(raw);
    return DateFormat('EEE, dd/MM/yyyy', 'vi_VN').format(dt);
  } catch (_) {
    return isoOrDate;
  }
}

/* ------------------------------ UI helpers ------------------------------ */

class _ErrorBox extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;
  const _ErrorBox({required this.message, required this.onRetry});

  @override
  Widget build(BuildContext context) => Center(
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.error_outline, size: 48, color: Colors.redAccent),
        const SizedBox(height: 12),
        Text(message, textAlign: TextAlign.center),
        const SizedBox(height: 8),
        FilledButton.icon(onPressed: onRetry, icon: const Icon(Icons.refresh), label: const Text('Thử lại')),
      ]),
    ),
  );
}

class _EmptyBox extends StatelessWidget {
  final String text;
  const _EmptyBox({this.text = 'Không có dữ liệu.'});

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(top: 8),
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      const Icon(Icons.event_available, size: 56, color: Colors.grey),
      const SizedBox(height: 8),
      Text(text, textAlign: TextAlign.center),
    ]),
  );
}

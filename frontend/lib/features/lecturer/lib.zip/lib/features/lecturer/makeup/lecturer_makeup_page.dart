// ignore_for_file: deprecated_member_use
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'makeup_api.dart';

class LecturerMakeupPage extends StatefulWidget {
  /// Tương thích ngược: chấp nhận cả `contextData` (mới) & `leaveItem` (cũ)
  const LecturerMakeupPage({
    super.key,
    Map<String, dynamic>? contextData,
    Map<String, dynamic>? leaveItem,
  }) : data = contextData ?? leaveItem;

  final Map<String, dynamic>? data;

  @override
  State<LecturerMakeupPage> createState() => _LecturerMakeupPageState();
}

class _LecturerMakeupPageState extends State<LecturerMakeupPage> {
  final _api = LecturerMakeupApi();

  final _formKey = GlobalKey<FormState>();
  final _dateCtrl = TextEditingController();
  final _startCtrl = TextEditingController();
  final _endCtrl = TextEditingController();
  final _roomCtrl = TextEditingController();
  final _noteCtrl = TextEditingController();

  bool _submitting = false;

  @override
  void initState() {
    super.initState();
    final d = widget.data ?? {};
    _roomCtrl.text = _pick(d, ['room', 'room_code', 'roomName']);
  }

  @override
  void dispose() {
    _dateCtrl.dispose();
    _startCtrl.dispose();
    _endCtrl.dispose();
    _roomCtrl.dispose();
    _noteCtrl.dispose();
    super.dispose();
  }

  String _pick(Map s, List<String> keys, {String def = ''}) {
    for (final k in keys) {
      final v = s[k];
      if (v != null && v.toString().trim().isNotEmpty) return v.toString().trim();
    }
    return def;
  }

  String _subjectOf(Map s) => _pick(s, [
    'subject',
    'subject_name',
    'course_name',
    'title',
    'assignment.subject.name',
  ], def: 'Môn học');

  String _classOf(Map s) {
    var v = _pick(s, ['class_name', 'class', 'class_code', 'group_name']);
    if (v.isNotEmpty) return v;
    final a = s['assignment'];
    if (a is Map) {
      v = _pick(a['class_unit'] as Map? ?? {}, ['name', 'code']);
      if (v.isNotEmpty) return v;
      v = _pick(a['classUnit'] as Map? ?? {}, ['name', 'code']);
    }
    return v;
  }

  String _cohortOf(Map s) {
    var c = _pick(s, ['cohort', 'k', 'course', 'batch']);
    if (c.isNotEmpty && !c.toUpperCase().startsWith('K')) c = 'K$c';
    return c;
  }

  String _dateVN(String? iso) {
    if (iso == null || iso.isEmpty) return '';
    final raw = iso.length >= 10 ? iso.substring(0, 10) : iso;
    try {
      final dt = DateTime.parse(raw);
      return DateFormat('EEE, dd/MM/yyyy', 'vi_VN').format(dt);
    } catch (_) {
      return iso;
    }
  }

  String _hhmm(String? t) {
    if (t == null || t.isEmpty) return '--:--';
    final s = t.trim();
    if (s.contains('T')) {
      try {
        final dt = DateTime.parse(s);
        return DateFormat('HH:mm').format(dt);
      } catch (_) {}
    }
    final parts = s.split(':');
    if (parts.length >= 2) return '${parts[0].padLeft(2, '0')}:${parts[1].padLeft(2, '0')}';
    return s;
  }

  String _timeOf(Map s) {
    final st = _pick(s, ['start_time', 'startTime', 'timeslot.start', 'period.start', 'slot.start']);
    final et = _pick(s, ['end_time', 'endTime', 'timeslot.end', 'period.end', 'slot.end']);
    return '${_hhmm(st)} - ${_hhmm(et)}';
  }

  Map<String, dynamic> _buildPayload() {
    final src = widget.data ?? {};
    final leaveRequestId =
        int.tryParse((_pick(src, ['leave_request_id', 'id', 'leaveId'])).toString()) ??
            int.tryParse(src['leave_request_id']?.toString() ?? '');
    final scheduleId =
        int.tryParse((_pick(src, ['schedule_id', 'session_id', 'scheduleId'])).toString()) ??
            int.tryParse(src['schedule_id']?.toString() ?? '');

    return {
      'leave_request_id': leaveRequestId,
      'schedule_id': scheduleId,
      'makeup_date': _dateCtrl.text, // yyyy-MM-dd
      'start_time': _startCtrl.text, // HH:mm
      'end_time': _endCtrl.text,     // HH:mm
      'room': _roomCtrl.text,
      'note': _noteCtrl.text,
    };
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _submitting = true);
    try {
      final payload = _buildPayload();
      await _api.create(payload);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Đã gửi đăng ký dạy bù.')),
      );
      Navigator.of(context).pop(); // quay lại list
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Gửi thất bại: $e')),
      );
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final data = widget.data ?? {};
    final cs = Theme.of(context).colorScheme;

    final subject = _subjectOf(data);
    final className = _classOf(data);
    final cohort = _cohortOf(data);
    final room = _pick(data, ['room', 'room_code', 'roomName']);
    final dateStr = (data['date'] ?? data['leave_date'] ?? data['session_date'])?.toString();
    final dateLabel = _dateVN(dateStr);
    final timeRange = _timeOf(data);

    return Scaffold(
      appBar: AppBar(title: const Text('Đăng ký dạy bù')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
        children: [
          // Bảng thông tin (giống bên Leave)
          Card(
            color: cs.surfaceVariant.withOpacity(.35),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
              side: BorderSide(color: cs.primary.withOpacity(.45), width: 1),
            ),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 12),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(subject, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
                const SizedBox(height: 8),
                if (className.isNotEmpty || cohort.isNotEmpty || room.isNotEmpty)
                  Text(
                    [
                      if (className.isNotEmpty) 'Lớp: $className',
                      if (cohort.isNotEmpty) cohort,
                      if (room.isNotEmpty) '• Phòng: $room',
                    ].join(' - ').replaceAll(' - •', ' •'),
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Colors.black54),
                  ),
                const SizedBox(height: 6),
                Text(
                  [
                    if (dateLabel.isNotEmpty) dateLabel,
                    if (timeRange != '--:-- - --:--') timeRange,
                  ].join(' • '),
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ]),
            ),
          ),

          const SizedBox(height: 16),
          const Divider(height: 1),

          const SizedBox(height: 16),
          Form(
            key: _formKey,
            child: Column(children: [
              // Ngày dạy bù
              TextFormField(
                controller: _dateCtrl,
                decoration: const InputDecoration(
                  labelText: 'Ngày dạy bù (yyyy-MM-dd)',
                  hintText: '2025-11-15',
                ),
                validator: (v) {
                  if (v == null || v.trim().isEmpty) return 'Nhập ngày dạy bù';
                  try {
                    DateTime.parse(v.trim());
                    return null;
                  } catch (_) {
                    return 'Định dạng yyyy-MM-dd';
                  }
                },
              ),
              const SizedBox(height: 12),

              Row(children: [
                Expanded(
                  child: TextFormField(
                    controller: _startCtrl,
                    decoration: const InputDecoration(labelText: 'Bắt đầu (HH:mm)', hintText: '07:00'),
                    validator: (v) => (v == null || !RegExp(r'^\d{2}:\d{2}$').hasMatch(v.trim()))
                        ? 'Định dạng HH:mm'
                        : null,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: TextFormField(
                    controller: _endCtrl,
                    decoration: const InputDecoration(labelText: 'Kết thúc (HH:mm)', hintText: '09:30'),
                    validator: (v) => (v == null || !RegExp(r'^\d{2}:\d{2}$').hasMatch(v.trim()))
                        ? 'Định dạng HH:mm'
                        : null,
                  ),
                ),
              ]),
              const SizedBox(height: 12),

              TextFormField(
                controller: _roomCtrl,
                decoration: const InputDecoration(labelText: 'Phòng', hintText: 'A2-305'),
                validator: (v) => (v == null || v.trim().isEmpty) ? 'Nhập phòng' : null,
              ),
              const SizedBox(height: 12),

              TextFormField(
                controller: _noteCtrl,
                minLines: 2,
                maxLines: 4,
                decoration: const InputDecoration(labelText: 'Ghi chú (tuỳ chọn)'),
              ),
              const SizedBox(height: 20),

              FilledButton.icon(
                onPressed: _submitting ? null : _submit,
                icon: const Icon(Icons.send),
                label: Text(_submitting ? 'Đang gửi...' : 'Gửi đăng ký dạy bù'),
              ),
            ]),
          ),
        ],
      ),
    );
  }
}

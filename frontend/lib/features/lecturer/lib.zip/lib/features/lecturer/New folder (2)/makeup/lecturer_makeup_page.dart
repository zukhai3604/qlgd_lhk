// ignore_for_file: deprecated_member_use
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:qlgd_lhk/common/widgets/tlu_app_bar.dart';
import 'makeup_api.dart';

class LecturerMakeupPage extends StatefulWidget {
  const LecturerMakeupPage({
    super.key,
    this.leaveItem, // nếu không truyền, lấy từ ModalRoute.of(context)!.settings.arguments / GoRouter.extra
  });

  final Map<String, dynamic>? leaveItem;

  @override
  State<LecturerMakeupPage> createState() => _LecturerMakeupPageState();
}

class _LecturerMakeupPageState extends State<LecturerMakeupPage> {
  final _api = LecturerMakeupApi();
  final _formKey = GlobalKey<FormState>();

  DateTime? _date;
  String? _className;
  final Set<int> _slots = {};
  bool _submitting = false;

  late final Map<String, dynamic> _leave;

  static const List<int> kSlots = [1,2,3,4,5,6,7,8,9,10,11,12];

  @override
  void initState() {
    super.initState();
    _leave = widget.leaveItem ?? {};
    _className = _pick(_leave, ['class_name', 'class', 'class_code']);
  }

  @override
  Widget build(BuildContext context) {
    final df = DateFormat('dd/MM/yyyy');

    final subject = _pick(_leave, ['subject', 'subject_name', 'course_name', 'title'], def: 'Môn học');
    final clazz   = _pick(_leave, ['class_name', 'class', 'class_code']);
    final dateStr = (_leave['__date__'] ?? _leave['date'] ?? _leave['leave_date'])?.toString();
    final date    = (dateStr != null && dateStr.length >= 10) ? DateTime.tryParse(dateStr.substring(0,10)) : null;
    final times   = _leave['times'] ?? _leave['timespan'] ?? _timeRangeOf(_leave);

    return Scaffold(
      appBar: const TluAppBar(title: 'Đăng ký dạy bù'),
      body: Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              Card(
                elevation: 0,
                color: Colors.brown.shade50,
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    _row(Icons.book_outlined, 'Môn', subject),
                    _row(Icons.class_, 'Lớp nghỉ', clazz.isEmpty ? '-' : clazz),
                    _row(Icons.event, 'Ngày nghỉ', date != null ? df.format(date) : '-'),
                    _row(Icons.schedule, 'Tiết', '$times'),
                  ]),
                ),
              ),

              const SizedBox(height: 12),
              Text('Chọn ngày dạy bù', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 6),
              OutlinedButton.icon(
                icon: const Icon(Icons.date_range),
                label: Text(_date == null ? 'Chọn ngày' : df.format(_date!)),
                onPressed: () async {
                  final now = DateTime.now();
                  final picked = await showDatePicker(
                    context: context,
                    initialDate: now,
                    firstDate: now,
                    lastDate: now.add(const Duration(days: 365)),
                    locale: const Locale('vi','VN'),
                  );
                  if (picked != null) setState(() => _date = picked);
                },
              ),

              const SizedBox(height: 12),
              Text('Chọn lớp học dạy bù', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 6),
              TextFormField(
                initialValue: _className,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: 'Tên lớp hoặc mã lớp',
                ),
                validator: (v) => (v==null || v.trim().isEmpty) ? 'Vui lòng nhập lớp' : null,
                onChanged: (v) => _className = v.trim(),
              ),

              const SizedBox(height: 12),
              Text('Chọn tiết dạy bù', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 6),
              Wrap(
                spacing: 8, runSpacing: 8,
                children: [
                  for (final s in kSlots)
                    FilterChip(
                      label: Text('Tiết $s'),
                      selected: _slots.contains(s),
                      onSelected: (on) => setState(() { on ? _slots.add(s) : _slots.remove(s); }),
                    )
                ],
              ),

              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  icon: _submitting
                      ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.send),
                  label: Text(_submitting ? 'Đang gửi...' : 'Gửi đăng ký dạy bù'),
                  onPressed: _submitting ? null : _submit,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    if (_date == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Vui lòng chọn ngày dạy bù')));
      return;
    }
    if (_slots.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Vui lòng chọn ít nhất 1 tiết')));
      return;
    }

    setState(() => _submitting = true);
    try {
      final payload = {
        'leave_request_id': _leave['id'] ?? _leave['leave_request_id'],
        'schedule_id': _leave['schedule_id'],
        'makeup_date': _date!.toIso8601String().split('T').first,
        'class_id_or_name': _className ?? _leave['class_name'],
        'timeslot_ids': _slots.toList()..sort(),
      };
      await _api.create(payload);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Đã gửi đăng ký dạy bù')));
      Navigator.of(context).pop(); // quay lại list
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi gửi đăng ký: $e')));
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  Widget _row(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(children: [
        Icon(icon, size: 18, color: Colors.brown),
        const SizedBox(width: 8),
        Text('$label: ', style: const TextStyle(fontWeight: FontWeight.w700)),
        Expanded(child: Text(value)),
      ]),
    );
  }

  String _pick(Map<String, dynamic> s, List<String> keys, {String def = ''}) {
    for (final k in keys) {
      final v = s[k];
      if (v != null && v.toString().trim().isNotEmpty) return v.toString().trim();
    }
    return def;
  }

  String _hhmm(String? t) {
    if (t == null || t.isEmpty) return '--:--';
    final parts = t.split(':');
    if (parts.length >= 2) return '${parts[0].padLeft(2, '0')}:${parts[1].padLeft(2, '0')}';
    return t;
  }

  String _timeRangeOf(Map<String, dynamic> s) {
    final st = _hhmm(s['start_time']?.toString());
    final et = _hhmm(s['end_time']?.toString());
    return '$st - $et';
  }
}

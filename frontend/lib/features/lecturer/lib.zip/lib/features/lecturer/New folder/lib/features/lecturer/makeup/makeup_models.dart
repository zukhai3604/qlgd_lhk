import 'package:flutter/foundation.dart';

@immutable
class LeaveItem {
  final int id;                 // leave_request_id (đơn nghỉ đã được duyệt)
  final int scheduleId;         // buổi học gốc
  final String subjectName;     // tên môn
  final String className;       // tên lớp
  final String room;            // phòng
  final DateTime date;          // ngày nghỉ
  final String times;           // ví dụ: "Tiết 3-5 (09:00-10:30)"

  const LeaveItem({
    required this.id,
    required this.scheduleId,
    required this.subjectName,
    required this.className,
    required this.room,
    required this.date,
    required this.times,
  });

  factory LeaveItem.fromJson(Map<String, dynamic> j) {
    return LeaveItem(
      id: j['id'] as int,
      scheduleId: j['schedule_id'] as int,
      subjectName: j['subject_name'] ?? j['subject'] ?? '-',
      className: j['class_name'] ?? j['class'] ?? '-',
      room: j['room'] ?? '-',
      date: DateTime.parse(j['date']),
      times: j['times'] ?? '-',
    );
  }
}

@immutable
class MakeupRequestItem {
  final int id;
  final int leaveId;            // tham chiếu đơn nghỉ
  final int scheduleId;         // tham chiếu buổi gốc
  final String className;       // lớp dạy bù
  final DateTime makeupDate;    // ngày dạy bù
  final List<int> timeslots;    // danh sách tiết dạy bù (1..n)
  final String status;          // pending/approved/rejected

  const MakeupRequestItem({
    required this.id,
    required this.leaveId,
    required this.scheduleId,
    required this.className,
    required this.makeupDate,
    required this.timeslots,
    required this.status,
  });

  factory MakeupRequestItem.fromJson(Map<String, dynamic> j) {
    return MakeupRequestItem(
      id: j['id'] as int,
      leaveId: j['leave_request_id'] as int,
      scheduleId: j['schedule_id'] as int,
      className: j['class_name'] ?? '-',
      makeupDate: DateTime.parse(j['makeup_date']),
      timeslots: (j['timeslot_ids'] as List?)?.map((e) => int.tryParse('$e') ?? 0).where((e) => e>0).toList() ?? const [],
      status: j['status'] ?? 'pending',
    );
  }
}

@immutable
class MakeupCreatePayload {
  final int leaveRequestId;     // id của đơn nghỉ đã duyệt
  final int scheduleId;         // buổi gốc
  final DateTime makeupDate;    // ngày dạy bù
  final String classIdOrName;   // có thể là id hoặc tên lớp
  final List<int> timeslotIds;  // tiết dạy bù

  const MakeupCreatePayload({
    required this.leaveRequestId,
    required this.scheduleId,
    required this.makeupDate,
    required this.classIdOrName,
    required this.timeslotIds,
  });

  Map<String, dynamic> toJson() => {
    'leave_request_id': leaveRequestId,
    'schedule_id': scheduleId,
    'makeup_date': makeupDate.toIso8601String().split('T').first, // yyyy-MM-dd
    'class_id_or_name': classIdOrName,
    'timeslot_ids': timeslotIds,
  };
}

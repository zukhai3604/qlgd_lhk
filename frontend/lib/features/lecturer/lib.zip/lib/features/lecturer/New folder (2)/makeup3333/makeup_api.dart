// ignore_for_file: deprecated_member_use

import 'package:dio/dio.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class LecturerMakeupApi {
  final Dio _dio;

  LecturerMakeupApi({Dio? dio})
      : _dio = dio ??
      Dio(
        BaseOptions(
          baseUrl: const String.fromEnvironment(
            'BASE_URL',
            defaultValue: 'http://127.0.0.1:8000',
          ),
          connectTimeout: const Duration(seconds: 8),
          receiveTimeout: const Duration(seconds: 15),
          headers: const {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
          },
        ),
      ) {
    // Interceptor: tự gắn Bearer token từ SecureStorage
    _dio.interceptors.add(
      InterceptorsWrapper(
        onRequest: (options, handler) async {
          try {
            const storage = FlutterSecureStorage();
            final token = await storage.read(key: 'access_token') ??
                await storage.read(key: 'auth_token');
            if (token != null && token.isNotEmpty) {
              options.headers['Authorization'] = 'Bearer $token';
            }
          } catch (_) {
            // Không có token cũng OK (nếu endpoint mở)
          }
          handler.next(options);
        },
      ),
    );
  }

  /* ===================== Helpers ===================== */

  List<Map<String, dynamic>> _asList(dynamic data) {
    if (data is List) {
      return data.map((e) => Map<String, dynamic>.from(e as Map)).toList();
    }
    if (data is Map && data['data'] is List) {
      return (data['data'] as List)
          .map((e) => Map<String, dynamic>.from(e as Map))
          .toList();
    }
    // Một số API trả ở key 'items'
    if (data is Map && data['items'] is List) {
      return (data['items'] as List)
          .map((e) => Map<String, dynamic>.from(e as Map))
          .toList();
    }
    return const [];
  }

  /* ===================== ĐƠN DẠY BÙ ===================== */

  // Liệt kê đơn dạy bù (có thể lọc theo status)
  Future<List<Map<String, dynamic>>> list({String? status}) async {
    final res = await _dio.get(
      '/api/lecturer/makeup-requests',
      queryParameters: {
        if (status != null && status.isNotEmpty) 'status': status,
      },
    );
    return _asList(res.data);
  }

  // Tạo đơn dạy bù
  // payload: {leave_request_id, schedule_id, makeup_date (yyyy-MM-dd),
  //           start_time (HH:mm), end_time (HH:mm), room, note}
  Future<Map<String, dynamic>> create(Map<String, dynamic> payload) async {
    final res = await _dio.post('/api/lecturer/makeup-requests', data: payload);
    return Map<String, dynamic>.from(res.data as Map);
  }

  // Hủy đơn dạy bù (khi chưa duyệt)
  Future<void> cancel(int id) async {
    await _dio.delete('/api/lecturer/makeup-requests/$id');
  }

  // Chi tiết 1 đơn dạy bù
  Future<Map<String, dynamic>> detail(int id) async {
    final res = await _dio.get('/api/lecturer/makeup-requests/$id');
    return Map<String, dynamic>.from(res.data as Map);
  }

  /* ========== BUỔI NGHỈ ĐÃ DUYỆT (để đăng ký dạy bù) ========== */
  /// Thứ tự thử endpoint (ưu tiên endpoint có trong BE bạn gửi):
  /// 1) **/api/lecturer/leaves?status=APPROVED**  ← cái này từ LeaveController
  /// 2) /api/lecturer/leave-requests?status=APPROVED
  /// 3) /api/lecturer/approved-leaves
  /// 4) Fallback: /api/lecturer/makeup-requests?status=APPROVED (để UI không trắng)
  Future<List<Map<String, dynamic>>> approvedLeaves({int page = 1}) async {
    // 1) Chuẩn theo BE bạn cung cấp (LeaveController@index)
    try {
      final r = await _dio.get(
        '/api/lecturer/leaves',
        queryParameters: {
          'status': 'APPROVED',
          'page': page,
        },
      );
      final list = _asList(r.data);
      if (list.isNotEmpty) return list;
    } catch (_) {}

    // 2) Biến thể "leave-requests"
    try {
      final r = await _dio.get(
        '/api/lecturer/leave-requests',
        queryParameters: {
          'status': 'APPROVED',
          'page': page,
        },
      );
      final list = _asList(r.data);
      if (list.isNotEmpty) return list;
    } catch (_) {}

    // 3) Endpoint riêng "approved-leaves"
    try {
      final r = await _dio.get(
        '/api/lecturer/approved-leaves',
        queryParameters: {'page': page},
      );
      final list = _asList(r.data);
      if (list.isNotEmpty) return list;
    } catch (_) {}

    // 4) Fallback cuối (không đúng domain bằng leave, nhưng tránh UI trắng)
    try {
      final r = await _dio.get(
        '/api/lecturer/makeup-requests',
        queryParameters: {
          'status': 'APPROVED',
          'page': page,
        },
      );
      return _asList(r.data);
    } catch (_) {
      return const [];
    }
  }
}

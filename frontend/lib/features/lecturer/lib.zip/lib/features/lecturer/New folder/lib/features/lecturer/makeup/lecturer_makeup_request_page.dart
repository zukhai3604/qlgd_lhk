import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:go_router/go_router.dart';

import 'makeup_api.dart';
import 'makeup_models.dart';

// TODO: Thay thế bằng provider DIO thực tế của dự án bạn (ví dụ: dioProvider)
final dioProvider = Provider<Dio>((ref) => throw UnimplementedError('Cấu hình dioProvider của dự án.'));

final lecturerMakeupApiProvider = Provider<LecturerMakeupApi>((ref) {
  final dio = ref.watch(dioProvider);
  return LecturerMakeupApi(dio);
});

final approvedLeavesProvider = FutureProvider.autoDispose<List<LeaveItem>>((ref) async {
  final api = ref.read(lecturerMakeupApiProvider);
  return api.fetchApprovedLeaves();
});

final makeupHistoryProvider = FutureProvider.autoDispose<List<MakeupRequestItem>>((ref) async {
  final api = ref.read(lecturerMakeupApiProvider);
  return api.fetchHistory();
});

class LecturerMakeupRequestPage extends ConsumerWidget {
  const LecturerMakeupRequestPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final approvedLeaves = ref.watch(approvedLeavesProvider);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Đăng ký dạy bù'),
        actions: [
          IconButton(
            tooltip: 'Lịch sử đăng ký',
            icon: const Icon(Icons.history),
            onPressed: () => context.push('/lecturer/makeup/history'),
          )
        ],
      ),
      body: approvedLeaves.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e,_) => Center(child: Text('Lỗi tải danh sách: $e')),
        data: (items) {
          if (items.isEmpty) {
            return const Center(child: Text('Không có buổi nghỉ đã được duyệt.'));
          }
          return ListView.separated(
            padding: const EdgeInsets.all(12),
            itemBuilder: (c, i) => _LeaveCard(item: items[i]),
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemCount: items.length,
          );
        },
      ),
    );
  }
}

class _LeaveCard extends ConsumerWidget {
  const _LeaveCard({required this.item});
  final LeaveItem item;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final df = DateFormat('EEE, dd/MM/yyyy', 'vi_VN');
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      child: Padding(
        padding: const EdgeInsets.all(14.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    item.subjectName,
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.orange.withOpacity(.1),
                    borderRadius: BorderRadius.circular(999),
                    border: Border.all(color: Colors.orange.shade300),
                  ),
                  child: const Text('Đã duyệt nghỉ', style: TextStyle(color: Colors.orange)),
                ),
              ],
            ),
            const SizedBox(height: 8),
            _InfoRow(icon: Icons.class_, label: 'Lớp', value: item.className),
            _InfoRow(icon: Icons.meeting_room_outlined, label: 'Phòng', value: item.room),
            _InfoRow(icon: Icons.event, label: 'Ngày nghỉ', value: df.format(item.date)),
            _InfoRow(icon: Icons.schedule, label: 'Thời gian', value: item.times),
            const SizedBox(height: 10),
            Align(
              alignment: Alignment.centerRight,
              child: FilledButton.icon(
                icon: const Icon(Icons.add),
                label: const Text('Đăng ký dạy bù'),
                onPressed: () => _openMakeupForm(context, ref, item),
              ),
            )
          ],
        ),
      ),
    );
  }

  void _openMakeupForm(BuildContext context, WidgetRef ref, LeaveItem leave) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
      ),
      builder: (_) => _MakeupForm(leave: leave),
    );
  }
}

class _InfoRow extends StatelessWidget {
  const _InfoRow({required this.icon, required this.label, required this.value});
  final IconData icon; final String label; final String value;
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(children: [
        Icon(icon, size: 18, color: Colors.brown),
        const SizedBox(width: 8),
        Text('$label: ', style: const TextStyle(fontWeight: FontWeight.w600)),
        Expanded(child: Text(value)),
      ]),
    );
  }
}

class _MakeupForm extends ConsumerStatefulWidget {
  const _MakeupForm({required this.leave});
  final LeaveItem leave;
  @override
  ConsumerState<_MakeupForm> createState() => _MakeupFormState();
}

class _MakeupFormState extends ConsumerState<_MakeupForm> {
  final _formKey = GlobalKey<FormState>();
  DateTime? _date;
  String? _className; // mặc định theo buổi nghỉ
  final Set<int> _selectedSlots = {};
  bool _submitting = false;

  static const List<int> kSlots = [1,2,3,4,5,6,7,8,9,10,11,12];

  @override
  void initState() {
    super.initState();
    _className = widget.leave.className;
  }

  @override
  Widget build(BuildContext context) {
    final df = DateFormat('dd/MM/yyyy');
    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
        left: 16, right: 16, top: 12,
      ),
      child: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(width: 56, height: 4, margin: const EdgeInsets.only(bottom: 12),
                  decoration: BoxDecoration(color: Colors.black26, borderRadius: BorderRadius.circular(999)),),
              ),
              Text('Đăng ký dạy bù', style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 8),

              Card(
                elevation: 0,
                color: Colors.brown.shade50,
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _InfoRow(icon: Icons.book_outlined, label: 'Môn', value: widget.leave.subjectName),
                      _InfoRow(icon: Icons.class_, label: 'Lớp nghỉ', value: widget.leave.className),
                      _InfoRow(icon: Icons.event, label: 'Ngày nghỉ', value: df.format(widget.leave.date)),
                      _InfoRow(icon: Icons.schedule, label: 'Tiết', value: widget.leave.times),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 12),
              Text('Chọn ngày dạy bù', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 6),
              OutlinedButton.icon(
                icon: const Icon(Icons.date_range),
                label: Text(_date == null ? 'Chọn ngày' : df.format(_date!)),
                onPressed: () async {
                  final now = DateTime.now();
                  final picked = await showDatePicker(
                    context: context,
                    initialDate: now,
                    firstDate: now.subtract(const Duration(days: 0)),
                    lastDate: now.add(const Duration(days: 365)),
                    locale: const Locale('vi','VN'),
                  );
                  if (picked != null) setState(() => _date = picked);
                },
              ),

              const SizedBox(height: 12),
              Text('Chọn lớp học dạy bù', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 6),
              TextFormField(
                initialValue: _className,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: 'Tên lớp hoặc mã lớp',
                ),
                validator: (v) => (v==null || v.trim().isEmpty) ? 'Vui lòng nhập lớp' : null,
                onChanged: (v) => _className = v.trim(),
              ),

              const SizedBox(height: 12),
              Text('Chọn tiết dạy bù', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 6),
              Wrap(
                spacing: 8, runSpacing: 8,
                children: [
                  for (final s in kSlots)
                    FilterChip(
                      label: Text('Tiết $s'),
                      selected: _selectedSlots.contains(s),
                      onSelected: (on) {
                        setState(() {
                          if (on) { _selectedSlots.add(s); } else { _selectedSlots.remove(s); }
                        });
                      },
                    )
                ],
              ),

              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  icon: _submitting
                      ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2,))
                      : const Icon(Icons.send),
                  label: Text(_submitting ? 'Đang gửi...' : 'Gửi đăng ký dạy bù'),
                  onPressed: _submitting ? null : _submit,
                ),
              ),
              const SizedBox(height: 12),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    if (_date == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Vui lòng chọn ngày dạy bù')));
      return;
    }
    if (_selectedSlots.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Vui lòng chọn ít nhất 1 tiết')));
      return;
    }

    setState(() => _submitting = true);
    try {
      final api = ref.read(lecturerMakeupApiProvider);
      final payload = MakeupCreatePayload(
        leaveRequestId: widget.leave.id,
        scheduleId: widget.leave.scheduleId,
        makeupDate: _date!,
        classIdOrName: _className ?? widget.leave.className,
        timeslotIds: _selectedSlots.toList()..sort(),
      );
      await api.createMakeup(payload);
      if (mounted) {
        Navigator.of(context).pop();
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Đã gửi đăng ký dạy bù')));
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi gửi đăng ký: $e')));
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }
}

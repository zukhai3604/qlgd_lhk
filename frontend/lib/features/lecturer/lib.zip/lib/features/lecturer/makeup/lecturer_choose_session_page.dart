// ignore_for_file: deprecated_member_use
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:qlgd_lhk/common/widgets/tlu_app_bar.dart';

// [SỬA 1] Import đúng API để lấy danh sách đơn nghỉ
import 'package:qlgd_lhk/features/lecturer/leave/leave_api.dart';

// [SỬA] Đổi tên trang cho đúng chức năng: chọn đơn nghỉ đã được duyệt
class ChooseApprovedLeavePage extends StatefulWidget {
  const ChooseApprovedLeavePage({super.key});

  @override
  State<ChooseApprovedLeavePage> createState() => _ChooseApprovedLeavePageState();
}

class _ChooseApprovedLeavePageState extends State<ChooseApprovedLeavePage> {
  // [SỬA 2] Sử dụng đúng đối tượng API
  final _leaveApi = LecturerLeaveApi();

  bool loading = true;
  String? error;
  List<Map<String, dynamic>> leaves = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    if (!mounted) return;
    setState(() {
      loading = true;
      error = null;
    });

    try {
      // [SỬA 3] Gọi đúng hàm `list` với status là 'approved'
      final raw = await _leaveApi.list(status: 'approved');

      // Phần xử lý và sắp xếp dữ liệu của bạn rất tốt, giữ nguyên
      final list = raw.map((e) => Map<String, dynamic>.from(e)).toList();
      for (final e in list) {
        // Lấy thông tin của buổi học gốc từ key 'schedule'
        final schedule = e['schedule'] as Map<String, dynamic>? ?? {};
        final rawDate = schedule['date']?.toString();
        e['__date__'] = (rawDate != null && rawDate.length >= 10) ? rawDate.substring(0, 10) : '';
      }

      if (list.length > 1) {
        list.sort((a, b) {
          final da = DateTime.tryParse(a['__date__'] ?? '') ?? DateTime(1970);
          final db = DateTime.tryParse(b['__date__'] ?? '') ?? DateTime(1970);
          return da.compareTo(db);
        });
      }

      if (mounted) {
        setState(() {
          leaves = list;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          error = 'Không tải được buổi nghỉ đã duyệt: $e';
        });
      }
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  // [SỬA 4] Điều hướng sang trang chọn lịch bù, truyền dữ liệu buổi học gốc
  void _navigateToMakeupSlot(Map<String, dynamic> leaveRequest) {
    final sessionData = leaveRequest['schedule'];
    if (sessionData == null || sessionData is! Map<String, dynamic>) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Lỗi: Không tìm thấy dữ liệu buổi học gốc.')),
      );
      return;
    }
    context.push('/makeup/choose-slot', extra: sessionData);
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    return Scaffold(
      // [SỬA] Đặt lại tên AppBar cho đúng chức năng
      appBar: const TluAppBar(title: Text('Chọn Buổi Nghỉ Cần Bù')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : error != null
          ? _ErrorBox(message: error!, onRetry: _load)
          : RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
          children: [
            const SizedBox(height: 4),
            Row(
              children: [
                // Giữ nguyên nút lịch sử
                Expanded(child: Container()), // Spacer
                OutlinedButton.icon(
                  onPressed: () => context.push('/makeup/history'),
                  icon: const Icon(Icons.history),
                  label: const Text('Lịch sử dạy bù'),
                ),
              ],
            ),
            const SizedBox(height: 12),
            if (leaves.isEmpty)
              _EmptyBox(onReload: _load)
            else
              ...leaves.map(
                    (leave) => _LeaveItemTile(
                  data: leave['schedule'] ?? {}, // Truyền dữ liệu buổi học gốc
                  onTap: () => _navigateToMakeupSlot(leave), // Gọi hàm điều hướng mới
                ),
              ),
          ],
        ),
      ),
    );
  }
}

/* ----------------------- Item + helpers + boxes ----------------------- */
// Tôi đã giữ lại toàn bộ các widget và hàm helper tuyệt vời của bạn ở dưới đây
// Chỉ có một sửa đổi nhỏ trong _LeaveItemTile để nó nhận đúng dữ liệu buổi học

class _LeaveItemTile extends StatelessWidget {
  final Map<String, dynamic> data;
  final VoidCallback onTap;
  const _LeaveItemTile({super.key, required this.data, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    // Các hàm helper của bạn sẽ hoạt động tốt với dữ liệu `schedule`
    final subject = _pickObj(data['subject'] as Map?, ['name'], def: 'Môn học');
    final className = _classNameOf(data);
    final cohort = _cohortOf(data);
    final room = _roomOf(data);

    final left = [
      if (className.isNotEmpty) 'Lớp: $className',
      if (cohort.isNotEmpty) cohort,
      if (room.isNotEmpty) '• Phòng: $room',
    ].where((e) => e.isNotEmpty).join(' - ').replaceAll(' - •', ' •');

    final dateStr = data['date']?.toString();
    final dateLabel = _dateVN(dateStr);
    final timeRange = _timeRangeOf(data);
    final timeline = [
      if (dateLabel.isNotEmpty) dateLabel,
      if (timeRange != '--:-- - --:--') timeRange,
    ].join(' • ');

    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 10),
      color: cs.surfaceVariant.withOpacity(.35),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: cs.primary.withOpacity(.45), width: 1),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(Icons.event_busy, size: 20, color: cs.primary),
                  const SizedBox(width: 8),
                  Text(
                    subject,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700),
                  ),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(color: Colors.green.shade100, borderRadius: BorderRadius.circular(999)),
                    child: Text(
                      'Đã duyệt nghỉ',
                      style: Theme.of(context)
                          .textTheme
                          .labelSmall
                          ?.copyWith(color: Colors.green.shade900, fontWeight: FontWeight.w700),
                    ),
                  ),
                ],
              ),
              const Divider(height: 16),
              if (left.isNotEmpty)
                Text(
                  left,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Colors.black54),
                ),
              const SizedBox(height: 6),
              Text(timeline, style: Theme.of(context).textTheme.bodySmall),
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: onTap,
                  icon: const Icon(Icons.add_task),
                  label: const Text('Đăng ký dạy bù cho buổi này'),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
//... (Tất cả các hàm helper và widget khác của bạn được giữ nguyên ở đây)
// _pick, _pickObj, _classNameOf, _cohortOf, _roomOf, _hhmm, _timeRangeOf, _dateVN, _ErrorBox, _EmptyBox

class _ErrorBox extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;
  const _ErrorBox({required this.message, required this.onRetry});

  @override
  Widget build(BuildContext context) => Center(
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.error_outline, size: 48, color: Colors.redAccent),
        const SizedBox(height: 12),
        Text(message, textAlign: TextAlign.center),
        const SizedBox(height: 8),
        FilledButton.icon(onPressed: onRetry, icon: const Icon(Icons.refresh), label: const Text('Thử lại')),
      ]),
    ),
  );
}

class _EmptyBox extends StatelessWidget {
  final VoidCallback onReload;
  const _EmptyBox({required this.onReload});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.only(top: 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.event_available, size: 56, color: Colors.grey),
            const SizedBox(height: 12),
            const Text(
              'Không có đơn nghỉ nào đã được duyệt\nđể bạn đăng ký dạy bù.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.black54),
            ),
            const SizedBox(height: 12),
            OutlinedButton.icon(onPressed: onReload, icon: const Icon(Icons.refresh), label: const Text('Tải lại')),
          ],
        ),
      ),
    );
  }
}

String _pick(Map s, List<String> keys, {String def = ''}) {
  for (final k in keys) {
    final v = s[k];
    if (v != null && v.toString().trim().isNotEmpty) return v.toString().trim();
  }
  return def;
}

String _pickObj(Map? obj, List<String> keys, {String def = ''}) {
  if (obj == null) return def;
  for (final k in keys) {
    final v = obj[k];
    if (v != null && v.toString().trim().isNotEmpty) return v.toString().trim();
  }
  return def;
}

String _classNameOf(Map<String, dynamic> s) {
  var v = _pick(s, ['class_name', 'class', 'class_code', 'group_name']);
  if (v.isNotEmpty) return v;
  final a = s['assignment'];
  if (a is Map) {
    v = _pickObj(a['class_unit'] as Map?, ['name', 'code']);
    if (v.isNotEmpty) return v;
    v = _pickObj(a['classUnit'] as Map?, ['name', 'code']);
  }
  return v;
}

String _cohortOf(Map<String, dynamic> s) {
  var c = _pick(s, ['cohort', 'k', 'course', 'batch']);
  if (c.isNotEmpty && !c.toUpperCase().startsWith('K')) c = 'K$c';
  return c;
}

String _roomOf(Map<String, dynamic> s) {
  if (s['room'] is Map) {
    final r = s['room'] as Map;
    final code = _pickObj(r, ['code', 'name', 'room_code', 'title', 'label']);
    if (code.isNotEmpty) return code;
  }
  if (s['room'] is String && (s['room'] as String).trim().isNotEmpty) {
    return (s['room'] as String).trim();
  }
  if (s['assignment'] is Map && (s['assignment'] as Map)['room'] is Map) {
    final r = (s['assignment'] as Map)['room'] as Map;
    final code = _pickObj(r, ['code', 'name', 'room_code', 'title', 'label']);
    if (code.isNotEmpty) return code;
  }
  final rooms = s['rooms'] ?? s['classrooms'] ?? s['room_list'];
  if (rooms is List && rooms.isNotEmpty) {
    final first = rooms.first;
    if (first is String && first.trim().isNotEmpty) return first.trim();
    if (first is Map) {
      final code = _pickObj(first, ['code', 'name', 'room_code', 'title', 'label']);
      if (code.isNotEmpty) return code;
    }
  }
  final building = _pick(s, ['building', 'building.name', 'block', 'block.name']);
  final num = _pick(s, ['room_number', 'roomNo', 'room_no', 'code', 'room_code']);
  if (building.isNotEmpty && num.isNotEmpty) return '$building-$num';
  if (num.isNotEmpty) return num;
  return _pick(s, ['room_code', 'roomName']);
}

String _hhmm(String? raw) {
  if (raw == null || raw.isEmpty) return '--:--';
  final s = raw.trim();
  if (s.contains('T')) {
    try {
      final dt = DateTime.parse(s);
      return DateFormat('HH:mm').format(dt);
    } catch (_) {}
  }
  final parts = s.split(':');
  if (parts.length >= 2) return '${parts[0].padLeft(2, '0')}:${parts[1].padLeft(2, '0')}';
  return s;
}

String _timeRangeOf(Map<String, dynamic> s) {
  final times = s['times'] ?? s['timespan'];
  if (times != null && times.toString().trim().isNotEmpty) {
    final str = times.toString();
    final parts = str.split('-').map((e) => e.trim()).toList();
    if (parts.length == 2) return '${_hhmm(parts[0])} - ${_hhmm(parts[1])}';
    return str;
  }
  final st = _pick(s, ['start_time', 'startTime', 'timeslot.start', 'period.start', 'slot.start']);
  final et = _pick(s, ['end_time', 'endTime', 'timeslot.end', 'period.end', 'slot.end']);
  return '${_hhmm(st)} - ${_hhmm(et)}';
}

String _dateVN(String? isoOrDate) {
  if (isoOrDate == null || isoOrDate.isEmpty) return '';
  final raw = isoOrDate.length >= 10 ? isoOrDate.substring(0, 10) : isoOrDate;
  try {
    final dt = DateTime.parse(raw);
    return DateFormat('EEE, dd/MM/yyyy', 'vi_VN').format(dt);
  } catch (_) {
    return isoOrDate;
  }
}

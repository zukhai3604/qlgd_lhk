import 'package:dio/dio.dart';
import 'package:qlgd_lhk/core/api_client.dart'; // Sử dụng ApiClient chung

class LecturerMakeupApi {
  LecturerMakeupApi({Dio? dio}) : _dio = dio ?? ApiClient().dio;
  final Dio _dio;

  // Ví dụ: Hàm tạo một yêu cầu dạy bù mới
  // Chúng ta sẽ hoàn thiện hàm này ở các bước sau.
  Future<Map<String, dynamic>> create(Map<String, dynamic> data) async {
    // Giả sử API endpoint là '/api/lecturer/makeup-requests'
    final res = await _dio.post('/api/lecturer/makeup-requests', data: data);
    return Map<String, dynamic>.from(res.data['data'] as Map);
  }

// Có thể thêm các hàm khác ở đây sau này, ví dụ:
// - list() để lấy lịch sử các đơn dạy bù
// - cancel() để hủy một đơn dạy bù
}

// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import 'package:qlgd_lhk/common/widgets/tlu_app_bar.dart';
import 'makeup_api.dart';

class LecturerMakeupHistoryPage extends StatefulWidget {
  const LecturerMakeupHistoryPage({super.key});

  @override
  State<LecturerMakeupHistoryPage> createState() => _LecturerMakeupHistoryPageState();
}

class _LecturerMakeupHistoryPageState extends State<LecturerMakeupHistoryPage> {
  final _api = LecturerMakeupApi();
  bool _loading = true;
  String? _error;
  List<Map<String, dynamic>> _items = const [];

  @override
  void initState() {
    super.initState();
    _fetch();
  }

  Future<void> _fetch() async {
    setState(() => _loading = true);
    try {
      final list = await _api.list(); // [{ id, status, subject, class_name, room, makeup_date, start_time, end_time, ...}]
      _items = list.map((e) => Map<String, dynamic>.from(e)).toList();
      _error = null;
    } catch (e) {
      _error = 'Không tải được lịch sử dạy bù: $e';
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  String _toVNDate(String iso) {
    try {
      final dt = DateTime.parse(iso.split(' ').first);
      return DateFormat('dd/MM/yyyy').format(dt);
    } catch (_) {
      return iso;
    }
  }

  // Helpers hiển thị (bóc tách mềm)
  String _pickStr(Map data, List<String> paths) {
    for (final p in paths) {
      dynamic cur = data;
      for (final seg in p.split('.')) {
        if (cur is Map && cur.containsKey(seg)) {
          cur = cur[seg];
        } else {
          cur = null;
          break;
        }
      }
      if (cur != null && cur.toString().trim().isNotEmpty) {
        return cur.toString().trim();
      }
    }
    return '';
  }

  String _subjectOf(Map e) {
    return _pickStr(e, [
      'subject', 'subject_name', 'assignment.subject.name', 'assignment.subject.title',
    ]).isEmpty ? 'Môn học' : _pickStr(e, [
      'subject', 'subject_name', 'assignment.subject.name', 'assignment.subject.title',
    ]);
  }

  String _classOf(Map e) {
    final s = _pickStr(e, [
      'class_name', 'class', 'assignment.class_unit.name', 'assignment.classUnit.name', 'group_name'
    ]);
    return s;
  }

  String _roomOf(Map e) {
    // object
    if (e['room'] is Map) {
      final r = e['room'] as Map;
      final code = _pickStr(r, ['code','name','room_code','title','label']);
      if (code.isNotEmpty) return code;
    }
    // string
    if (e['room'] is String && (e['room'] as String).trim().isNotEmpty) return (e['room'] as String).trim();
    // list
    final rooms = e['rooms'] ?? e['classrooms'] ?? e['room_list'];
    if (rooms is List && rooms.isNotEmpty) {
      final first = rooms.first;
      if (first is String && first.trim().isNotEmpty) return first.trim();
      if (first is Map) {
        final code = _pickStr(first, ['code','name','room_code','title','label']);
        if (code.isNotEmpty) return code;
      }
    }
    // building + number
    final building = _pickStr(e, ['building', 'building.name', 'block', 'block.name']);
    final num = _pickStr(e, ['room_number', 'roomNo', 'room_no', 'code', 'room_code']);
    if (building.isNotEmpty && num.isNotEmpty) return '$building-$num';
    if (num.isNotEmpty) return num;
    return '';
  }

  String _hhmm(String raw) {
    if (raw.isEmpty) return '--:--';
    final s = raw.trim();
    if (s.contains('T')) {
      try {
        final dt = DateTime.parse(s);
        return DateFormat('HH:mm').format(dt);
      } catch (_) {}
    }
    final parts = s.split(':');
    if (parts.length >= 2) return '${parts[0].padLeft(2,'0')}:${parts[1].padLeft(2,'0')}';
    return s;
  }

  ({String label, Color color}) _chipFor(String status) {
    switch ((status).toUpperCase()) {
      case 'APPROVED': return (label: 'Đã duyệt', color: Colors.green);
      case 'REJECTED': return (label: 'Từ chối', color: Colors.red);
      case 'PENDING':  return (label: 'Chờ duyệt', color: Colors.orange);
      case 'CANCELED': return (label: 'Đã hủy', color: Colors.grey);
      default:         return (label: status,   color: Colors.blueGrey);
    }
  }

  Future<void> _cancel(Map item) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Hủy đăng ký dạy bù?'),
        content: const Text('Đơn đang chờ duyệt sẽ bị hủy.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Không')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Hủy')),
        ],
      ),
    );
    if (ok != true) return;

    try {
      await _api.cancel(int.parse('${item['id']}'));
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Đã hủy đơn dạy bù.')));
        _fetch();
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi khi hủy: $e')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: const TluAppBar(title: 'Lịch sử dạy bù'),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
          ? _ErrorBox(message: _error!, onRetry: _fetch)
          : RefreshIndicator(
        onRefresh: _fetch,
        child: _items.isEmpty
            ? const _EmptyBox()
            : ListView.builder(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
          itemCount: _items.length,
          itemBuilder: (context, i) {
            final it = _items[i];
            final subject = _subjectOf(it);
            final cls = _classOf(it);
            final room = _roomOf(it);
            final date = _pickStr(it, ['makeup_date', 'date']).toString();
            final dateVN = date.isNotEmpty ? _toVNDate(date) : '';
            final st = _hhmm(_pickStr(it, ['start_time','startTime','timeslot.start']));
            final et = _hhmm(_pickStr(it, ['end_time','endTime','timeslot.end']));
            final status = _chipFor((it['status'] ?? '').toString());

            final parts = <String>[];
            if (cls.isNotEmpty) parts.add('Lớp: $cls');
            if (dateVN.isNotEmpty) parts.add(dateVN);
            parts.add('$st - $et');
            if (room.isNotEmpty) parts.add('Phòng: $room');
            final subLine = parts.join(' · ');

            return Card(
              elevation: 1,
              margin: const EdgeInsets.only(bottom: 10),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
                side: BorderSide(color: status.color.withOpacity(0.5)),
              ),
              child: ListTile(
                title: Text(subject, style: const TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text(subLine),
                trailing: Wrap(
                  spacing: 8,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                    Chip(
                      label: Text(status.label, style: const TextStyle(fontSize: 10)),
                      backgroundColor: status.color.withOpacity(0.15),
                      side: BorderSide.none,
                      visualDensity: VisualDensity.compact,
                    ),
                    if ((it['status'] ?? '').toString().toUpperCase() == 'PENDING')
                      IconButton(
                        onPressed: () => _cancel(it),
                        tooltip: 'Hủy đơn',
                        icon: const Icon(Icons.cancel),
                        color: cs.error,
                      ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

class _ErrorBox extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;
  const _ErrorBox({required this.message, required this.onRetry});
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.error_outline, size: 48, color: Colors.redAccent),
          const SizedBox(height: 8),
          Text(message, textAlign: TextAlign.center),
          const SizedBox(height: 8),
          FilledButton.icon(onPressed: onRetry, icon: const Icon(Icons.refresh), label: const Text('Thử lại')),
        ]),
      ),
    );
  }
}

class _EmptyBox extends StatelessWidget {
  const _EmptyBox();
  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.event_available, size: 56, color: Colors.grey),
            SizedBox(height: 12),
            Text('Chưa có đăng ký dạy bù nào.', textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }
}

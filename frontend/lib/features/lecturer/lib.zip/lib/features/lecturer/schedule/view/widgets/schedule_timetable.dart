import 'package:flutter/material.dart';

class ScheduleTimetable extends StatelessWidget {
  const ScheduleTimetable({super.key});

  @override
  Widget build(BuildContext context) {
    return const Card(
      child: Padding(
        padding: EdgeInsets.all(16.0),
        child: Text('Timetable placeholder'),
      ),
    );
  }
}

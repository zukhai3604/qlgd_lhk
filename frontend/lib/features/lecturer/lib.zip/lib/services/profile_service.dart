import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/api_client.dart';

abstract class ProfileService {
  Future<Map<String, dynamic>> getProfile();
  Future<Map<String, dynamic>> updateProfile(Map<String, dynamic> payload);
  Future<List<Map<String, dynamic>>> listFaculties();
  Future<List<Map<String, dynamic>>> listDepartments({int? facultyId});
  Future<void> changePassword({
    required String oldPassword,
    required String newPassword,
  });
}

class BackendProfileService implements ProfileService {
  BackendProfileService({Dio? dio}) : _dio = dio ?? ApiClient().dio;

  final Dio _dio;

  @override
  Future<Map<String, dynamic>> getProfile() async {
    final response = await _dio.get('/api/me');
    return _extractObject(response.data);
  }

  @override
  Future<Map<String, dynamic>> updateProfile(
      Map<String, dynamic> payload) async {
    final body = Map<String, dynamic>.from(payload)
      ..removeWhere((key, value) => value == null);

    final response = await _dio.patch(
      '/api/me/profile',
      data: body,
    );
    return _extractObject(response.data);
  }

  @override
  Future<List<Map<String, dynamic>>> listFaculties() async {
    final response = await _dio.get('/api/faculties');
    return _extractList(response.data);
  }

  @override
  Future<List<Map<String, dynamic>>> listDepartments({int? facultyId}) async {
    final response = await _dio.get(
      '/api/departments',
      queryParameters: {
        if (facultyId != null) 'faculty_id': facultyId,
      },
    );
    return _extractList(response.data);
  }

  @override
  Future<void> changePassword({
    required String oldPassword,
    required String newPassword,
  }) async {
    await _dio.post(
      '/api/me/change-password',
      data: {
        'current_password': oldPassword,
        'password': newPassword,
        'password_confirmation': newPassword,
      },
    );
  }

  Map<String, dynamic> _extractObject(dynamic source) {
    if (source is Map<String, dynamic>) {
      if (source['data'] is Map) {
        return Map<String, dynamic>.from(source['data'] as Map);
      }
      return Map<String, dynamic>.from(source);
    }
    throw const FormatException('Response payload is not a JSON object');
  }

  List<Map<String, dynamic>> _extractList(dynamic source) {
    if (source is Map && source['data'] is List) {
      return (source['data'] as List)
          .whereType<Map>()
          .map((e) => Map<String, dynamic>.from(e))
          .toList();
    }
    if (source is List) {
      return source
          .whereType<Map>()
          .map((e) => Map<String, dynamic>.from(e))
          .toList();
    }
    throw const FormatException('Response payload is not a JSON array');
  }
}

final profileServiceProvider = Provider<ProfileService>(
  (ref) => BackendProfileService(),
);

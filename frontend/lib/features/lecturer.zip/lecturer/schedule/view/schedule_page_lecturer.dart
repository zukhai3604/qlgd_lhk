import 'package:flutter/material.dart';
import 'package:qlgd_lhk/common/widgets/tlu_app_bar.dart';

class SchedulePageLecturer extends StatelessWidget {
  const SchedulePageLecturer({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const TluAppBar(),
      body: const Center(child: Text('Schedule content for Lecturer')),
    );
  }
}



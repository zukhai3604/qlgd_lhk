﻿import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:qlgd_lhk/common/widgets/tlu_app_bar.dart';

import '../../../services/notifications_service.dart';

class LecturerNotificationsPage extends StatefulWidget {
  const LecturerNotificationsPage({super.key});

  @override
  State<LecturerNotificationsPage> createState() => _LecturerNotificationsPageState();
}

class _LecturerNotificationsPageState extends State<LecturerNotificationsPage> {
  final _service = NotificationsService();
  bool _loading = true;
  String? _error;
  List<Map<String, dynamic>> _items = const [];

  @override
  void initState() {
    super.initState();
    _fetch();
  }

  Future<void> _fetch() async {
    setState(() => _loading = true);
    try {
      final res = await _service.list(isRead: null, page: 1);
      _items = (res['data'] as List).cast<Map<String, dynamic>>();
      _error = null;
    } on DioException catch (e) {
      _error = e.response?.data is Map
          ? (e.response?.data['message']?.toString() ?? 'Không thể tải thông báo')
          : 'Không thể tải thông báo';
    } catch (e) {
      _error = 'Không thể tải thông báo';
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _markRead(int id) async {
    try {
      await _service.markRead(id);
      await _fetch();
    } catch (_) {}
  }

  Future<void> _delete(int id) async {
    try {
      await _service.delete(id);
      await _fetch();
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const TluAppBar(),
      body: SafeArea(
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : _error != null
                ? _buildError()
                : RefreshIndicator(
                    onRefresh: _fetch,
                    child: _items.isEmpty
                        ? const ListTile(title: Text('Chưa có thông báo'))
                        : ListView.separated(
                            padding: const EdgeInsets.symmetric(vertical: 8),
                            itemBuilder: (context, index) {
                              final n = _items[index];
                              final id = n['id'] as int?;
                              final title = (n['title'] ?? '').toString();
                              final body = (n['body'] ?? '').toString();
                              final status = (n['status'] ?? 'UNREAD').toString();
                              final createdAt = (n['created_at'] ?? '').toString();
                              final isUnread = status.toUpperCase() == 'UNREAD';
                              return ListTile(
                                leading: Icon(
                                  isUnread
                                      ? Icons.notifications_active_outlined
                                      : Icons.notifications_none_outlined,
                                  color: isUnread
                                      ? Theme.of(context).colorScheme.primary
                                      : null,
                                ),
                                title: Text(title),
                                subtitle: Text(
                                  [body, createdAt]
                                      .where((e) => e.isNotEmpty)
                                      .join('\n'),
                                ),
                                onTap: id == null ? null : () => _markRead(id),
                                trailing: id == null
                                    ? null
                                    : IconButton(
                                        tooltip: 'Xóa',
                                        icon: const Icon(Icons.delete_outline),
                                        onPressed: () => _delete(id),
                                      ),
                              );
                            },
                            separatorBuilder: (_, __) => const Divider(height: 1),
                            itemCount: _items.length,
                          ),
                  ),
      ),
    );
  }

  Widget _buildError() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.error_outline, size: 48, color: Colors.redAccent),
          const SizedBox(height: 8),
          Text(_error ?? 'Đã xảy ra lỗi.'),
          const SizedBox(height: 8),
          FilledButton(onPressed: _fetch, child: const Text('Thử lại')),
        ],
      ),
    );
  }
}

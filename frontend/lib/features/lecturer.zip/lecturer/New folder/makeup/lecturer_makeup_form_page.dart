import 'package:flutter/material.dart';
import 'package:qlgd_lhk/common/widgets/tlu_app_bar.dart';

class LecturerMakeupFormPage extends StatefulWidget {
  // Trang này cần thông tin tổng hợp từ các bước trướcfinal Map<String, dynamic> makeupInfo;

  const LecturerMakeupFormPage({
    super.key,
    required this.makeupInfo,
  });

  @override
  State<LecturerMakeupFormPage> createState() => _LecturerMakeupFormPageState();
}

class _LecturerMakeupFormPageState extends State<LecturerMakeupFormPage> {
  final _noteController = TextEditingController();

  @override
  void dispose() {
    _noteController.dispose();
    super.dispose();
  }

  void _submitRequest() {
    // Logic gửi yêu cầu sẽ được thêm vào đây
    // Ví dụ: gọi hàm từ LecturerMakeupApi
    final note = _noteController.text;
    print('Gửi yêu cầu dạy bù với ghi chú: $note');
    print('Dữ liệu: ${widget.makeupInfo}');
    // Sau khi gửi thành công, có thể quay về trang chủ hoặc trang lịch sử
  }

  @override
  Widget build(BuildContext context) {
    // Tạm thời hiển thị dữ liệu để kiểm tra
    final originalSession = widget.makeupInfo['original_session'];
    final makeupSlot = widget.makeupInfo['makeup_slot'];

    return Scaffold(
      appBar: TluAppBar(
        title: 'Xác Nhận Đăng Ký Dạy Bù',
        showBackButton: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Bước 3: Xác nhận thông tin', style: TextStyle(color: Colors.grey)),
            const SizedBox(height: 16),

            // Phần thông tin tóm tắt
            _buildInfoCard(
              context,
              title: 'Buổi Nghỉ Gốc',
              icon: Icons.calendar_today_outlined,
              iconColor: Colors.redAccent,
              lines: [
                'Môn: ${originalSession?['subject']?['name'] ?? 'N/A'}',
                'Ngày: ${originalSession?['date'] ?? 'N/A'}',
                'Tiết: ${originalSession?['start_time']} - ${originalSession?['end_time']}',
              ],
            ),

            const SizedBox(height: 16),

            _buildInfoCard(
              context,
              title: 'Lịch Dạy Bù (Dự kiến)',
              icon: Icons.calendar_month,
              iconColor: Colors.green,
              lines: [
                'Ngày: ${makeupSlot?['date'] ?? 'Chưa chọn'}',
                'Tiết: ${makeupSlot?['period'] ?? 'Chưa chọn'}',
                'Phòng: ${makeupSlot?['room'] ?? 'Chưa chọn'}',
              ],
            ),

            const SizedBox(height: 24),

            // Phần ghi chú
            Text('Ghi chú (nếu có)', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            TextField(
              controller: _noteController,
              maxLines: 3,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                hintText: 'Nhập nội dung ghi chú cho phòng đào tạo...',
              ),
            ),

            const SizedBox(height: 32),

            // Nút gửi
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                icon: const Icon(Icons.send),
                label: const Text('Gửi Yêu Cầu'),
                onPressed: _submitRequest,
                style: FilledButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Widget con để hiển thị thông tin cho đẹp
  Widget _buildInfoCard(BuildContext context, {required String title, required IconData icon, required Color iconColor, required List<String> lines}) {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: Colors.grey.shade300),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: iconColor),
                const SizedBox(width: 8),
                Text(
                  title,
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(fontSize: 18),
                ),
              ],
            ),
            const Divider(height: 20),
            ...lines.map((line) => Text(line, style: const TextStyle(height: 1.6))),
          ],
        ),
      ),
    );
  }
}

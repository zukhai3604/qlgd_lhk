import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'makeup_models.dart';
import 'lecturer_makeup_request_page.dart';

class LecturerMakeupHistoryPage extends ConsumerWidget {
  const LecturerMakeupHistoryPage({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final history = ref.watch(makeupHistoryProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('Lịch sử đăng ký dạy bù')),
      body: history.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e,_) => Center(child: Text('Lỗi tải lịch sử: $e')),
        data: (items) {
          if (items.isEmpty) return const Center(child: Text('Chưa có đăng ký nào.'));
          return ListView.separated(
            padding: const EdgeInsets.all(12),
            itemCount: items.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (_, i) => _HistoryCard(item: items[i]),
          );
        },
      ),
    );
  }
}

class _HistoryCard extends StatelessWidget {
  const _HistoryCard({required this.item});
  final MakeupRequestItem item;
  @override
  Widget build(BuildContext context) {
    final df = DateFormat('EEE, dd/MM/yyyy', 'vi_VN');
    Color c; String label;
    switch (item.status) {
      case 'approved': c = Colors.green; label = 'Đã duyệt'; break;
      case 'rejected': c = Colors.red; label = 'Từ chối'; break;
      default: c = Colors.orange; label = 'Đang duyệt';
    }
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      child: Padding(
        padding: const EdgeInsets.all(14.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(child: Text(item.className, style: Theme.of(context).textTheme.titleMedium)),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: c.withOpacity(.1), borderRadius: BorderRadius.circular(999), border: Border.all(color: c.withOpacity(.7)),
                  ),
                  child: Text(label, style: TextStyle(color: c)),
                ),
              ],
            ),
            const SizedBox(height: 8),
            _InfoRow(icon: Icons.event_available, label: 'Ngày dạy bù', value: df.format(item.makeupDate)),
            _InfoRow(icon: Icons.schedule, label: 'Tiết', value: item.timeslots.join(', ')),
          ],
        ),
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  const _InfoRow({required this.icon, required this.label, required this.value});
  final IconData icon; final String label; final String value;
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(children: [
        Icon(icon, size: 18, color: Colors.brown),
        const SizedBox(width: 8),
        Text('$label: ', style: const TextStyle(fontWeight: FontWeight.w600)),
        Expanded(child: Text(value)),
      ]),
    );
  }
}

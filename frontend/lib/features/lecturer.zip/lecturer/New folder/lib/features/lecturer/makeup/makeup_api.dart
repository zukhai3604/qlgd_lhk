import 'package:dio/dio.dart';
import 'makeup_models.dart';

class LecturerMakeupApi {
  final Dio _dio;
  LecturerMakeupApi(this._dio);

  // Điều chỉnh nếu backend của bạn có prefix /api trên baseUrl.
  static const String _approvedLeavesPath = '/lecturer/leave-requests';
  static const String _historyPath = '/lecturer/makeup-requests';
  static const String _createPath = '/lecturer/makeup-requests';

  Future<List<LeaveItem>> fetchApprovedLeaves() async {
    final res = await _dio.get(_approvedLeavesPath, queryParameters: {'status': 'approved'});
    final data = res.data is Map ? (res.data['data'] ?? res.data) : res.data;
    final list = (data as List?) ?? const [];
    return list.map((e) => LeaveItem.fromJson(Map<String,dynamic>.from(e))).toList();
  }

  Future<List<MakeupRequestItem>> fetchHistory() async {
    final res = await _dio.get(_historyPath);
    final data = res.data is Map ? (res.data['data'] ?? res.data) : res.data;
    final list = (data as List?) ?? const [];
    return list.map((e) => MakeupRequestItem.fromJson(Map<String,dynamic>.from(e))).toList();
  }

  Future<void> createMakeup(MakeupCreatePayload payload) async {
    await _dio.post(_createPath, data: payload.toJson());
  }
}

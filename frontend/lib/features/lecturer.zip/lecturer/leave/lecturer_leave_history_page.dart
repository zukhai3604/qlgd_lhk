// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../schedule/service.dart';
import 'package:qlgd_lhk/common/widgets/tlu_app_bar.dart';
import '../leave/leave_api.dart';

class LecturerLeaveHistoryPage extends StatefulWidget {
  const LecturerLeaveHistoryPage({super.key});

  @override
  State<LecturerLeaveHistoryPage> createState() => _LecturerLeaveHistoryPageState();
}

class _LecturerLeaveHistoryPageState extends State<LecturerLeaveHistoryPage> {
  final _leaveApi = LecturerLeaveApi();
  final _scheduleSvc = LecturerScheduleService();

  bool _loading = true;
  String? _error;
  List<Map<String, dynamic>> _items = const [];

  @override
  void initState() {
    super.initState();
    _fetch();
  }

  Future<void> _fetch() async {
    setState(() => _loading = true);
    try {
      final leaves = await _leaveApi.list(); // [{id, schedule_id, status, reason, note, ...}]
      final results = <Map<String, dynamic>>[];

      for (final lr in leaves) {
        final scheduleId = lr['schedule_id'];
        if (scheduleId == null) continue;

        Map<String, dynamic> sd = {};
        try {
          final raw = await _scheduleSvc.getDetail(int.parse(scheduleId.toString()));
          sd = Map<String, dynamic>.from(raw);
        } catch (_) {
          // Không chặn toàn bộ – nếu không lấy được detail thì vẫn hiển thị phần đã có
        }

        // Gom dữ liệu hiển thị
        final subject = _subjectOf(sd, lr);
        final className = _classOf(sd, lr);
        final dateIso = _dateIsoOf(sd, lr);
        final start = _hhmm(_startOf(sd, lr));
        final end   = _hhmm(_endOf(sd, lr));
        final room  = _roomOf(sd, lr);

        results.add({
          'leave_request_id': lr['id'],
          'status': (lr['status'] ?? 'UNKNOWN').toString(),
          'reason': (lr['reason'] ?? '').toString(),
          'note': (lr['note'] ?? '').toString(),
          'schedule_id': scheduleId,
          'subject': subject,
          'class_name': className,
          'date': dateIso,
          'start_time': start,
          'end_time': end,
          'room': room,
        });
      }

      _items = results;
      _error = null;
    } catch (e) {
      _error = 'Không tải được lịch sử xin nghỉ: $e';
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _handleTap(Map<String, dynamic> item) async {
    final status = item['status']?.toString().toUpperCase();
    if (status == 'APPROVED') {
      final extra = {
        'id': item['schedule_id'],
        'leave_request_id': item['leave_request_id'],
        'subjectName': (item['subject'] ?? '').toString(),
        'date': _toDDMMYYYY(item['date']?.toString()),
        'timeSlot': [
          if ((item['start_time'] ?? '').toString().isNotEmpty &&
              (item['end_time'] ?? '').toString().isNotEmpty)
            '${item['start_time']} - ${item['end_time']}'
        ].join(),
        'reason': (item['reason'] ?? '').toString(),
      };
      if (!mounted) return;
      context.push('/makeup-request', extra: extra);
      return;
    }

    if (status == 'PENDING') {
      final confirm = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Hủy đơn xin nghỉ?'),
          content: const Text('Đơn này đang chờ duyệt. Bạn có muốn hủy không?'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Không')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Hủy đơn')),
          ],
        ),
      );
      if (confirm == true) {
        try {
          await _leaveApi.cancel(item['leave_request_id'] as int);
          if (!mounted) return;
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Đã hủy đơn xin nghỉ.')));
          _fetch();
        } catch (e) {
          if (!mounted) return;
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi khi hủy: $e')));
        }
      }
      return;
    }

    if (status == 'REJECTED') {
      if (!mounted) return;
      showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Đơn bị từ chối'),
          content: Text('Lý do: ${item['note']?.toString().isNotEmpty == true ? item['note'] : 'Không có ghi chú.'}'),
          actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Đã hiểu'))],
        ),
      );
    }
  }

  String _toDDMMYYYY(String? iso) {
    if (iso == null || iso.isEmpty) return '';
    try {
      final dt = DateTime.parse(iso.split(' ').first);
      return DateFormat('dd/MM/yyyy').format(dt);
    } catch (_) {
      return iso;
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final tt = Theme.of(context).textTheme;

    return Scaffold(
      appBar: const TluAppBar(title: 'Lịch sử xin nghỉ'),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? _ErrorBox(message: _error!, onRetry: _fetch)
              : RefreshIndicator(
                  onRefresh: _fetch,
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
                        child: Text(
                          'Danh sách các đơn xin nghỉ đã gửi. Nhấn vào đơn "Đã duyệt" để tạo lịch dạy bù.',
                          style: tt.bodySmall?.copyWith(color: cs.onSurfaceVariant),
                        ),
                      ),
                      Expanded(
                        child: _items.isEmpty
                            ? const _EmptyBox()
                            : ListView.builder(
                                padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                                itemCount: _items.length,
                                itemBuilder: (context, i) {
                                  final item = _items[i];

                                  final subject = (item['subject'] ?? 'Môn học').toString();
                                  final className = (item['class_name'] ?? '').toString();
                                  final date = _toDDMMYYYY(item['date']?.toString());
                                  final start = (item['start_time'] ?? '').toString();
                                  final end = (item['end_time'] ?? '').toString();
                                  final room = (item['room'] ?? '').toString();

                                  final line2 = [
                                    if (className.isNotEmpty) 'Lớp: $className',
                                  ].join(' - ');

                                  final timePart = (start.isNotEmpty && end.isNotEmpty) ? '$start - $end' : '';
                                  final roomPart = room.isNotEmpty ? 'Phòng: $room' : '';
                                  final line3 = [
                                    if (date.isNotEmpty) date,
                                    if (timePart.isNotEmpty) timePart,
                                    if (roomPart.isNotEmpty) roomPart,
                                  ].join(' • ');

                                  final status = _getStatus(item['status']?.toString() ?? '');

                                  return Card(
                                    elevation: 1,
                                    margin: const EdgeInsets.only(bottom: 10),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(12),
                                      side: BorderSide(color: status.color.withOpacity(0.5)),
                                    ),
                                    child: ListTile(
                                      title: Text(subject, style: const TextStyle(fontWeight: FontWeight.w700)),
                                      subtitle: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          if (line2.isNotEmpty) Text(line2),
                                          if (line3.isNotEmpty) Text(line3),
                                        ],
                                      ),
                                      trailing: Chip(
                                        label: Text(status.label, style: const TextStyle(fontSize: 10)),
                                        backgroundColor: status.color.withOpacity(0.15),
                                        side: BorderSide.none,
                                        visualDensity: VisualDensity.compact,
                                      ),
                                      onTap: () => _handleTap(item),
                                    ),
                                  );
                                },
                              ),
                      ),
                    ],
                  ),
                ),
    );
  }

  // ================== Robust extractors (đã cập nhật) ==================

  /// Lấy chuỗi theo danh sách đường dẫn (hỗ trợ "a.b.c")
  String _pickStr(Map data, List<String> paths) {
    for (final p in paths) {
      dynamic cur = data;
      for (final seg in p.split('.')) {
        if (cur is Map && cur.containsKey(seg)) {
          cur = cur[seg];
        } else {
          cur = null;
          break;
        }
      }
      if (cur != null && cur.toString().trim().isNotEmpty) {
        return cur.toString().trim();
      }
    }
    return '';
  }

  String _subjectOf(Map<String, dynamic> sd, Map<String, dynamic> lr) {
    final fromSd = _pickStr(sd, [
      'assignment.subject.name',
      'assignment.subject.title',
      'subject.name',
      'subject.title',
      'subject_name',
      'subject',
    ]);
    if (fromSd.isNotEmpty) return fromSd;
    return _pickStr(lr, ['subject', 'subject_name']).ifEmpty('Môn học');
  }

  String _classOf(Map<String, dynamic> sd, Map<String, dynamic> lr) {
    final fromSd = _pickStr(sd, [
      'assignment.class_unit.name',
      'assignment.class_unit.code',
      'class_unit.name',
      'class_unit.code',
      'class_name',
      'class',
    ]);
    if (fromSd.isNotEmpty) return fromSd;
    return _pickStr(lr, ['class_name', 'class']).ifEmpty('Lớp');
  }

  String _roomOf(Map<String, dynamic> sd, Map<String, dynamic> lr) {
    final fromSd = _pickStr(sd, ['room.name', 'room.code', 'room']);
    if (fromSd.isNotEmpty) return fromSd;
    return _pickStr(lr, ['room.name', 'room.code', 'room', 'room_code']).ifEmpty('');
  }

  /// Chuẩn hóa ngày ISO (yyyy-MM-dd)
  String _dateIsoOf(Map<String, dynamic> sd, Map<String, dynamic> lr) {
    final raw = _pickStr(sd, [
      'session_date', // tên đúng trong schema của bạn
      'date',
      'start_at',
      'timeslot.date',
      'period.date',
    ]).ifEmpty(_pickStr(lr, ['session_date', 'date']));
    if (raw.isEmpty) return '';
    final only = raw.split(' ').first;
    try {
      final dt = DateTime.parse(only);
      return DateFormat('yyyy-MM-dd').format(dt);
    } catch (_) {
      return only;
    }
  }

  String _startOf(Map<String, dynamic> sd, Map<String, dynamic> lr) {
    return _pickStr(sd, [
      'timeslot.start_time',
      'timeslot.start',
      'start_time',
      'startTime',
      'slot.start',
    ]).ifEmpty(_pickStr(lr, ['timeslot.start_time', 'start_time', 'startTime']));
  }

  String _endOf(Map<String, dynamic> sd, Map<String, dynamic> lr) {
    return _pickStr(sd, [
      'timeslot.end_time',
      'timeslot.end',
      'end_time',
      'endTime',
      'slot.end',
    ]).ifEmpty(_pickStr(lr, ['timeslot.end_time', 'end_time', 'endTime']));
  }

  String _hhmm(String raw) {
    if (raw.isEmpty) return '';
    final s = raw.trim();
    if (s.contains('T')) {
      try {
        final dt = DateTime.parse(s);
        return DateFormat('HH:mm').format(dt);
      } catch (_) {}
    }
    final parts = s.split(':');
    if (parts.length >= 2) {
      return '${parts[0].padLeft(2, '0')}:${parts[1].padLeft(2, '0')}';
    }
    return s;
  }

  // ================== UI helpers ==================

  ({String label, Color color}) _getStatus(String status) {
    switch (status.toUpperCase()) {
      case 'APPROVED':
        return (label: 'Đã duyệt', color: Colors.green);
      case 'REJECTED':
        return (label: 'Từ chối', color: Colors.red);
      case 'PENDING':
        return (label: 'Chờ duyệt', color: Colors.orange);
      case 'CANCELED':
        return (label: 'Đã hủy', color: Colors.grey);
      default:
        return (label: status, color: Colors.blueGrey);
    }
  }
}

extension _EmptyStr on String {
  String ifEmpty(String alt) => isEmpty ? alt : this;
}

class _ErrorBox extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;
  const _ErrorBox({required this.message, required this.onRetry});
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.error_outline, size: 48, color: Colors.redAccent),
          const SizedBox(height: 8),
          Text(message, textAlign: TextAlign.center),
          const SizedBox(height: 8),
          FilledButton.icon(onPressed: onRetry, icon: const Icon(Icons.refresh), label: const Text('Thử lại')),
        ]),
      ),
    );
  }
}

class _EmptyBox extends StatelessWidget {
  const _EmptyBox();
  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.history_toggle_off, size: 56, color: Colors.grey),
            SizedBox(height: 12),
            Text('Bạn chưa gửi đơn xin nghỉ nào.', textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }
}

import 'package:dio/dio.dart';
import 'package:qlgd_lhk/core/api_client.dart';

class LecturerMakeupApi {
  LecturerMakeupApi({Dio? dio}) : _dio = dio ?? ApiClient().dio;
  final Dio _dio;

  // Buổi nghỉ đã được duyệt (để đăng ký dạy bù)
  Future<List<Map<String, dynamic>>> approvedLeaves({int page = 1}) async {
    final res = await _dio.get(
      '/api/lecturer/leave-requests',
      queryParameters: {'status': 'APPROVED', 'page': page},
    );
    final data = res.data;
    final List raw = data is Map ? (data['data'] ?? const []) : (data as List? ?? const []);
    return raw.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
  }

  // Lịch sử đăng ký dạy bù
  Future<List<Map<String, dynamic>>> history({int page = 1}) async {
    final res = await _dio.get(
      '/api/lecturer/makeup-requests',
      queryParameters: {'page': page},
    );
    final data = res.data;
    final List raw = data is Map ? (data['data'] ?? const []) : (data as List? ?? const []);
    return raw.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
  }

  // Tạo đơn đăng ký dạy bù
  Future<Map<String, dynamic>> create(Map<String, dynamic> payload) async {
    final res = await _dio.post('/api/lecturer/makeup-requests', data: payload);
    final body = res.data;
    if (body is Map && body['data'] is Map) {
      return Map<String, dynamic>.from(body['data'] as Map);
    }
    return Map<String, dynamic>.from(body as Map);
  }
}

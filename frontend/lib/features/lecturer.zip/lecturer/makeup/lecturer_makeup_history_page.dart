// ignore_for_file: deprecated_member_use
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:qlgd_lhk/common/widgets/tlu_app_bar.dart';
import 'makeup_api.dart';

class LecturerMakeupHistoryPage extends StatefulWidget {
  const LecturerMakeupHistoryPage({super.key});

  @override
  State<LecturerMakeupHistoryPage> createState() => _LecturerMakeupHistoryPageState();
}

class _LecturerMakeupHistoryPageState extends State<LecturerMakeupHistoryPage> {
  final _api = LecturerMakeupApi();
  bool _loading = true;
  String? _error;
  List<Map<String, dynamic>> _items = const [];

  @override
  void initState() {
    super.initState();
    _fetch();
  }

  Future<void> _fetch() async {
    setState(() => _loading = true);
    try {
      final list = await _api.history();
      setState(() {
        _items = list;
        _error = null;
      });
    } catch (e) {
      setState(() => _error = '$e');
    } finally {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const TluAppBar(title: 'Lịch sử đăng ký dạy bù'),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null) return Center(child: Text('Lỗi tải dữ liệu: $_error'));
    if (_items.isEmpty) return const Center(child: Text('Chưa có đăng ký nào.'));

    final df = DateFormat('EEE, dd/MM/yyyy', 'vi_VN');

    return RefreshIndicator(
      onRefresh: _fetch,
      child: ListView.separated(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(12),
        itemCount: _items.length,
        separatorBuilder: (_, __) => const SizedBox(height: 10),
        itemBuilder: (_, i) {
          final it = _items[i];
          final clazz = it['class_name'] ?? '-';
          final date  = it['makeup_date'] != null ? DateTime.tryParse('${it['makeup_date']}') : null;
          final slots = (it['timeslot_ids'] as List?)?.join(', ') ?? '-';

          final status = (it['status'] ?? 'PENDING').toString().toUpperCase();
          Color c; String label;
          switch (status) {
            case 'APPROVED': c = Colors.green; label = 'Đã duyệt'; break;
            case 'REJECTED': c = Colors.red; label = 'Từ chối'; break;
            default: c = Colors.orange; label = 'Đang duyệt';
          }

          return Card(
            elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            child: Padding(
              padding: const EdgeInsets.all(14.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(child: Text(clazz, style: Theme.of(context).textTheme.titleMedium)),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: c.withOpacity(.08),
                          borderRadius: BorderRadius.circular(999),
                          border: Border.all(color: c.withOpacity(.6)),
                        ),
                        child: Text(label, style: TextStyle(color: c)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  _infoRow(Icons.event_available, 'Ngày dạy bù', date != null ? df.format(date) : '-'),
                  _infoRow(Icons.schedule, 'Tiết', '$slots'),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _infoRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(children: [
        Icon(icon, size: 18, color: Colors.brown),
        const SizedBox(width: 8),
        Text('$label: ', style: const TextStyle(fontWeight: FontWeight.w700)),
        Expanded(child: Text(value)),
      ]),
    );
  }
}

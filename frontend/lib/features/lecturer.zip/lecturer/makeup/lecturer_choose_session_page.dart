// ignore_for_file: deprecated_member_use
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import 'package:qlgd_lhk/common/widgets/tlu_app_bar.dart';
import 'makeup_api.dart';

class LecturerChooseSessionPage extends StatefulWidget {
  const LecturerChooseSessionPage({super.key});

  @override
  State<LecturerChooseSessionPage> createState() => _LecturerChooseSessionPageState();
}

class _LecturerChooseSessionPageState extends State<LecturerChooseSessionPage> {
  final _api = LecturerMakeupApi();

  bool loading = true;
  String? error;
  List<Map<String, dynamic>> leaves = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      loading = true;
      error = null;
    });
    try {
      final list = await _api.approvedLeaves(page: 1);
      for (final e in list) {
        final raw = (e['date'] ?? e['leave_date'])?.toString();
        if (raw != null && raw.length >= 10) e['__date__'] = raw.substring(0, 10);
      }
      list.sort((a, b) {
        final da = DateTime.tryParse('${a['__date__'] ?? ''}') ?? DateTime(1970);
        final db = DateTime.tryParse('${b['__date__'] ?? ''}') ?? DateTime(1970);
        return da.compareTo(db);
      });
      leaves = list;
    } catch (e) {
      error = 'Không tải được buổi nghỉ đã duyệt: $e';
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: const TluAppBar(),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : error != null
          ? _ErrorBox(message: error!, onRetry: _load)
          : RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
          children: [
            const SizedBox(height: 4),
            Row(
              children: [
                Expanded(
                  child: Text(
                    'Chọn buổi nghỉ để đăng ký dạy bù',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800),
                  ),
                ),
                OutlinedButton.icon(
                  onPressed: () => context.push('/lecturer/makeup/history'),
                  icon: const Icon(Icons.history),
                  label: const Text('Lịch sử đăng ký'),
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
                    side: BorderSide(color: cs.primary),
                    foregroundColor: cs.primary,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),

            if (leaves.isEmpty)
              const _EmptyBox(text: 'Chưa có buổi nghỉ đã duyệt. Kéo xuống để tải lại.')
            else
              ...leaves.map(
                    (s) => _LeaveItemTile(
                  data: s,
                  onTap: () => context.push('/lecturer/makeup/form', extra: s),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

/* ----------------------- Item + helpers + boxes ----------------------- */

class _LeaveItemTile extends StatelessWidget {
  final Map<String, dynamic> data;
  final VoidCallback onTap;
  const _LeaveItemTile({super.key, required this.data, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final subject = _pick(data, ['subject', 'subject_name', 'course_name', 'title'], def: 'Môn học');
    final className = _pick(data, ['class_name', 'class', 'class_code', 'group_name']);
    var cohort = _pick(data, ['cohort', 'k', 'course', 'batch']);
    if (cohort.isNotEmpty && !cohort.toUpperCase().startsWith('K')) cohort = 'K$cohort';
    final room = _pick(data, ['room', 'room_code', 'roomName']);

    final left = [
      if (className.isNotEmpty) 'Lớp: $className',
      if (cohort.isNotEmpty) cohort,
      if (room.isNotEmpty) ' • Phòng: $room',
    ].join(' - ').replaceAll(' -  •', ' •');

    final dateStr = (data['__date__'] ?? data['date'] ?? data['leave_date'])?.toString();
    final dateLabel = (dateStr != null && dateStr.length >= 10)
        ? DateFormat('EEE, dd/MM/yyyy', 'vi_VN').format(DateTime.parse(dateStr.substring(0, 10)))
        : '';
    final times = data['times'] ?? data['timespan'];
    final timeRange = (times != null && times.toString().trim().isNotEmpty) ? '$times' : _timeRangeOf(data);
    final timeline = [dateLabel, timeRange].where((e) => e.isNotEmpty && e != '--:-- - --:--').join(' • ');

    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 10),
      color: cs.surfaceVariant.withOpacity(.35),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: cs.primary.withOpacity(.45), width: 1),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(color: cs.primary.withOpacity(.12), shape: BoxShape.circle),
                child: Icon(Icons.event_busy, size: 18, color: cs.primary),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(subject,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 4),
                  if (left.isNotEmpty)
                    Text(left,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Colors.black54)),
                  const SizedBox(height: 6),
                  Text(timeline, style: Theme.of(context).textTheme.bodySmall),
                ]),
              ),
              const SizedBox(width: 8),
              FilledButton.icon(
                onPressed: onTap,
                icon: const Icon(Icons.add),
                label: const Text('Đăng ký dạy bù'),
                style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8)),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(color: cs.primaryContainer, borderRadius: BorderRadius.circular(999)),
                child: Text('Đã duyệt nghỉ',
                    style: Theme.of(context)
                        .textTheme
                        .labelSmall
                        ?.copyWith(color: cs.onPrimaryContainer, fontWeight: FontWeight.w700)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

String _pick(Map<String, dynamic> s, List<String> keys, {String def = ''}) {
  for (final k in keys) {
    final v = s[k];
    if (v != null && v.toString().trim().isNotEmpty) return v.toString().trim();
  }
  return def;
}

String _hhmm(String? t) {
  if (t == null || t.isEmpty) return '--:--';
  final parts = t.split(':');
  if (parts.length >= 2) {
    return '${parts[0].padLeft(2, '0')}:${parts[1].padLeft(2, '0')}';
  }
  return t;
}

String _timeRangeOf(Map<String, dynamic> s) {
  final st = _hhmm(s['start_time']?.toString());
  final et = _hhmm(s['end_time']?.toString());
  return '$st - $et';
}

class _ErrorBox extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;
  const _ErrorBox({required this.message, required this.onRetry});

  @override
  Widget build(BuildContext context) => Center(
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.error_outline, size: 48, color: Colors.redAccent),
        const SizedBox(height: 12),
        Text(message, textAlign: TextAlign.center),
        const SizedBox(height: 8),
        FilledButton.icon(onPressed: onRetry, icon: const Icon(Icons.refresh), label: const Text('Thử lại')),
      ]),
    ),
  );
}

class _EmptyBox extends StatelessWidget {
  final String text;
  const _EmptyBox({this.text = 'Không có dữ liệu.'});

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(top: 8),
    child: Column(mainAxisSize: MainAxisSize.min, children: const [
      Icon(Icons.event_available, size: 56, color: Colors.grey),
      SizedBox(height: 8),
      Text('Không có dữ liệu.', textAlign: TextAlign.center),
    ]),
  );
}

import 'package:dio/dio.dart';

Dio buildDio() {
  const base = String.fromEnvironment('API_BASE', defaultValue: 'http://127.0.0.1:8888');
  return Dio(BaseOptions(
    baseUrl: base,
    connectTimeout: const Duration(seconds: 10),
    receiveTimeout: const Duration(seconds: 10),
  ));
}

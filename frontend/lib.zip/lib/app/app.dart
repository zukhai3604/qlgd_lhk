import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:qlgd_lhk/core/storage/token_storage.dart';
import 'package:qlgd_lhk/features/auth/presentation/login_page.dart';
import 'package:qlgd_lhk/features/schedule/presentation/schedule_page_lecturer.dart';

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ProviderScope(
      child: MaterialApp(
        title: 'QLGD LHK',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(useMaterial3: true, colorSchemeSeed: const Color(0xFF1976D2)),
        home: const AuthGate(),
        routes: {
          '/login': (_) => const LoginPage(),
          '/home' : (_) => const SchedulePageLecturer(),
        },
      ),
    );
  }
}

class App extends MyApp {
  const App({super.key});
}

class AuthGate extends StatefulWidget {
  const AuthGate({super.key});
  @override
  State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  @override
  void initState() { super.initState(); _decide(); }

  Future<void> _decide() async {
    try {
      final storage = TokenStorage();
      final token = await storage.getAccessToken();
      if (!mounted) return;
      if (token != null && token.isNotEmpty) {
        Navigator.of(context).pushReplacementNamed('/home');
      } else {
        Navigator.of(context).pushReplacementNamed('/login');
      }
    } catch (_) {
      if (!mounted) return;
      Navigator.of(context).pushReplacementNamed('/login');
    }
  }

  @override
  Widget build(BuildContext context) =>
      const Scaffold(body: Center(child: CircularProgressIndicator()));
}

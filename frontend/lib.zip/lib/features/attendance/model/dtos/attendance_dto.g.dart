// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'attendance_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$AttendanceDtoImpl _$$AttendanceDtoImplFromJson(Map<String, dynamic> json) =>
    _$AttendanceDtoImpl(
      id: json['id'] as String,
      studentId: json['studentId'] as String,
      scheduleId: json['scheduleId'] as String,
      isPresent: json['isPresent'] as bool,
    );

Map<String, dynamic> _$$AttendanceDtoImplToJson(_$AttendanceDtoImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'studentId': instance.studentId,
      'scheduleId': instance.scheduleId,
      'isPresent': instance.isPresent,
    };

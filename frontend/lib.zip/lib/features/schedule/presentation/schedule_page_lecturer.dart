import 'package:flutter/material.dart';
class SchedulePageLecturer extends StatelessWidget {
  const SchedulePageLecturer({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Lịch giảng (Giảng viên)')),
      body: ListView.separated(
        itemBuilder: (_, i) => ListTile(
          title: Text('Tiết học #$i'),
          subtitle: const Text('Môn học / Lớp / Phòng'),
          trailing: const Text('planned'),
        ),
        separatorBuilder: (_, __) => const Divider(height: 1),
        itemCount: 10,
      ),
    );
  }
}

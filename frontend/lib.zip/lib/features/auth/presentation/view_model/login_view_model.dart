import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../shared/providers.dart';          // ✅ 4 cấp lên tới lib/shared

class LoginState {
  final bool isLoggingIn;
  final String? errorMessage;
  final bool obscurePassword;
  const LoginState({
    this.isLoggingIn = false,
    this.errorMessage,
    this.obscurePassword = true,
  });
  LoginState copyWith({bool? isLoggingIn, String? errorMessage, bool? obscurePassword}) =>
      LoginState(
        isLoggingIn: isLoggingIn ?? this.isLoggingIn,
        errorMessage: errorMessage,
        obscurePassword: obscurePassword ?? this.obscurePassword,
      );
}

class LoginViewModel extends StateNotifier<LoginState> {
  final Ref ref;
  LoginViewModel(this.ref) : super(const LoginState());

  String? validateEmail(String? v) =>
      (v == null || v.trim().isEmpty) ? 'Email không được để trống' : null;
  String? validatePassword(String? v) =>
      (v == null || v.isEmpty) ? 'Mật khẩu không được để trống' : null;

  void togglePasswordVisibility() =>
      state = state.copyWith(obscurePassword: !state.obscurePassword);

  Future<void> login({required String email, required String password}) async {
    state = state.copyWith(isLoggingIn: true, errorMessage: null);
    try {
      final repo = ref.read(authRepoProvider);
      await repo.login(email: email, password: password);
      state = state.copyWith(isLoggingIn: false);
    } catch (e) {
      state = state.copyWith(isLoggingIn: false, errorMessage: 'Đăng nhập thất bại: $e');
    }
  }
}

final loginViewModelProvider =
StateNotifierProvider<LoginViewModel, LoginState>((ref) => LoginViewModel(ref));

import 'package:flutter/material.dart';

class LoginHeader extends StatelessWidget {
  const LoginHeader({super.key}); // có const để dùng const ở LoginPage

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Column(
      children: [
        Icon(Icons.school, size: 64, color: cs.primary),
        const SizedBox(height: 8),
        Text('Đăng nhập hệ thống', style: Theme.of(context).textTheme.titleLarge),
      ],
    );
  }
}

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart'; // ✅ SỬA LỖI: Import Riverpod
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:go_router/go_router.dart';

import '../../../common/providers/auth_state_provider.dart'; // ✅ SỬA LỖI: Import AuthStateProvider
import '../../../core/api_client.dart';

// ✅ SỬA LỖI: Chuyển thành ConsumerStatefulWidget
class LecturerAccountPage extends ConsumerStatefulWidget {
  const LecturerAccountPage({super.key});

  @override
  ConsumerState<LecturerAccountPage> createState() => _LecturerAccountPageState();
}

// ✅ SỬA LỖI: Chuyển thành ConsumerState
class _LecturerAccountPageState extends ConsumerState<LecturerAccountPage> {
  bool loading = true;
  String? error;
  Map<String, dynamic> me = {};

  @override
  void initState() {
    super.initState();
    _loadMe();
  }

  Future<void> _loadMe() async {
    if (!mounted) return;
    setState(() {
      loading = true;
      error = null;
    });

    try {
      final dio = ApiClient().dio;
      final res = await dio.get('/api/me');

      final body = res.data;
      final map = (body is Map && body['data'] is Map) ? body['data'] : body;
      if (map is! Map) throw Exception('Dữ liệu hồ sơ không hợp lệ.');

      if (!mounted) return;
      setState(() {
        me = Map<String, dynamic>.from(map);
        loading = false;
        error = null;
      });
    } on DioException catch (e) {
      if (!mounted) return;
      String msg = 'Lỗi tải hồ sơ (HTTP ${e.response?.statusCode ?? 'null'})';
      if (e.response?.statusCode == 401) {
        msg = 'Phiên đăng nhập đã hết hạn. Vui lòng đăng nhập lại.';
        await _logout();
      }
      setState(() {
        error = msg;
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        error = e.toString().replaceFirst('Exception: ', '');
        loading = false;
      });
    }
  }

  // Helper: lấy chuỗi từ map lồng nhau
  String _pickS(List<String> keys, [String defaultValue = '---']) {
    for (final k in keys) {
      dynamic cur = me;
      for (final p in k.split('.')) {
        if (cur is Map && cur.containsKey(p)) {
          cur = cur[p];
        } else {
          cur = null;
          break;
        }
      }
      if (cur != null && '$cur'.trim().isNotEmpty) return '$cur'.trim();
    }
    return defaultValue;
  }

  String _fmtDob(String raw) {
    try {
      final d = DateTime.parse(raw);
      return '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';
    } catch (_) {
      return raw;
    }
  }

  String _vnRole(String r) {
    switch (r.toUpperCase()) {
      case 'ADMIN': return 'Quản trị';
      case 'TRAINING_DEPARTMENT': return 'Phòng Đào tạo';
      case 'LECTURER': return 'Giảng viên';
      default: return r;
    }
  }

  Future<void> _logout() async {
    const storage = FlutterSecureStorage();
    await storage.delete(key: 'access_token');
    await storage.delete(key: 'auth_token');

    // ✅ SỬA LỖI: Cập nhật trạng thái global trước khi điều hướng
    if (mounted) {
      ref.read(authStateProvider.notifier).logout();
      context.go('/login');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(''),
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: Theme.of(context).colorScheme.onSurface,
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (loading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(error!, style: const TextStyle(color: Colors.red), textAlign: TextAlign.center),
              const SizedBox(height: 12),
              FilledButton.icon(
                onPressed: _loadMe,
                icon: const Icon(Icons.refresh),
                label: const Text('Tải lại'),
              ),
            ],
          ),
        ),
      );
    }

    // ==== Map dữ liệu ra UI ====
    final name = _pickS(['user.name', 'name', 'full_name']);
    final dobRaw = _pickS(['lecturer.date_of_birth', 'date_of_birth', 'dob'], '');
    final dob = dobRaw.isEmpty ? '---' : _fmtDob(dobRaw);
    final gender = _pickS(['lecturer.gender', 'gender']);
    final phone = _pickS(['user.phone', 'phone']);
    final email = _pickS(['user.email', 'email']);
    final department = _pickS(['lecturer.department.name', 'department.name', 'lecturer.department']);
    final faculty = _pickS(['lecturer.department.faculty.name', 'department.faculty.name', 'faculty.name']);
    final roleStr = _pickS(['user.role', 'role'], '');
    final role = roleStr.isEmpty ? '---' : _vnRole(roleStr);
    final avatar = _pickS(['avatar_url', 'avatar'], '');

    return RefreshIndicator(
      onRefresh: _loadMe,
      child: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        children: [
          const SizedBox(height: 16),
          const Text(
            'TRƯỜNG ĐẠI HỌC THỦY LỢI',
            textAlign: TextAlign.center,
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.blue),
          ),
          const SizedBox(height: 24),
          Center(
            child: CircleAvatar(
              radius: 50,
              backgroundColor: Theme.of(context).colorScheme.primaryContainer,
              backgroundImage: (avatar.isNotEmpty && avatar.startsWith('http')) ? NetworkImage(avatar) : null,
              child: avatar.isEmpty ? const Icon(Icons.person, size: 44) : null,
            ),
          ),
          const SizedBox(height: 24),
          _buildInfoCard('Tên giảng viên', name),
          _buildInfoCard('Ngày sinh', dob),
          Row(
            children: [
              Expanded(child: _buildInfoCard('Giới tính', gender)),
              const SizedBox(width: 16),
              Expanded(child: _buildInfoCard('Số điện thoại', phone)),
            ],
          ),
          _buildInfoCard('Email', email),
          _buildInfoCard('Bộ môn', department),
          Row(
            children: [
              Expanded(child: _buildInfoCard('Vai trò', role)),
              const SizedBox(width: 16),
              Expanded(child: _buildInfoCard('Khoa', faculty)),
            ],
          ),
          const SizedBox(height: 32),
          Text('Cài đặt', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          Card(
            elevation: 2,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: Column(
              children: [
                _buildSettingsTile(
                  icon: Icons.settings_outlined,
                  title: 'Cài đặt tài khoản',
                  onTap: () {},
                ),
                const Divider(height: 1, indent: 16, endIndent: 16),
                _buildSettingsTile(
                  icon: Icons.help_outline,
                  title: 'Trợ giúp',
                  onTap: () {},
                ),
                const Divider(height: 1, indent: 16, endIndent: 16),
                _buildSettingsTile(
                  icon: Icons.logout,
                  title: 'Đăng xuất',
                  color: Colors.red,
                  onTap: () {
                    showDialog(
                      context: context,
                      builder: (ctx) => AlertDialog(
                        title: const Text('Xác nhận đăng xuất'),
                        content: const Text('Bạn có chắc chắn muốn đăng xuất?'),
                        actions: [
                          TextButton(onPressed: () => Navigator.of(ctx).pop(), child: const Text('Hủy')),
                          FilledButton(
                            onPressed: () {
                              Navigator.of(ctx).pop();
                              _logout();
                            },
                            child: const Text('Đăng xuất'),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  Widget _buildInfoCard(String label, String value) {
    return Card(
      elevation: 2,
      margin: const EdgeInsets.only(bottom: 16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Colors.grey[600])),
            const SizedBox(height: 4),
            Text(value, style: Theme.of(context).textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }

  Widget _buildSettingsTile({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
    Color? color,
  }) {
    return ListTile(
      leading: Icon(icon, color: color),
      title: Text(title, style: TextStyle(color: color)),
      trailing: const Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey),
      onTap: onTap,
    );
  }
}
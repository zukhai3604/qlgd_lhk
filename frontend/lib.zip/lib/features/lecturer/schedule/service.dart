import 'package:dio/dio.dart';
import '../../../core/api_client.dart';

class LecturerScheduleService {
  final Dio _dio = ApiClient().dio;

  // ===== Week =====
  Future<Map<String, dynamic>> getWeek({String? date}) async {
    final res = await _dio.get(
      '/api/lecturer/schedule/week',
      queryParameters: {if (date != null) 'date': date},
    );
    return Map<String, dynamic>.from(res.data);
  }

  // ===== Detail =====
  Future<Map<String, dynamic>> getDetail(int id) async {
    final res = await _dio.get('/api/lecturer/schedule/$id');
    final data = res.data is Map ? (res.data['data'] ?? res.data) : res.data;
    return Map<String, dynamic>.from(data);
  }

  // ===== Materials =====
  Future<List<Map<String, dynamic>>> listMaterials(int id) async {
    final res = await _dio.get('/api/lecturer/schedule/$id/materials');
    final List list =
    (res.data is Map ? res.data['data'] ?? [] : res.data) as List;
    return list.map((e) => Map<String, dynamic>.from(e)).toList();
  }

  // UI mới đang gọi getMaterials -> alias về listMaterials
  Future<List<Map<String, dynamic>>> getMaterials(int sessionId) =>
      listMaterials(sessionId);

  // Thêm nội dung/tài liệu (UI mới dùng)
  Future<void> addMaterial(int sessionId, String title) async {
    await _dio.post('/api/lecturer/schedule/$sessionId/materials', data: {
      'title': title,
      // Nếu BE của bạn bắt buộc file_url thì thêm ở đây:
      // 'file_url': 'https://example.com',
    });
  }

  // ===== Report =====
  // UI mới gọi kiểu đặt tên:
  // submitReport(sessionId: 1, status: 'done', note: '...', content: '...')
  Future<void> submitReport({
    required int sessionId,
    String? status,
    String? note,
    String? content,
    String? issues,
    String? nextPlan,
  }) async {
    final body = <String, dynamic>{};
    if (status != null) body['status'] = status;
    if (note != null && note.trim().isNotEmpty) body['note'] = note.trim();
    if (content != null && content.trim().isNotEmpty) {
      body['content'] = content.trim();
    }
    if (issues != null && issues.trim().isNotEmpty) {
      body['issues'] = issues.trim();
    }
    if (nextPlan != null && nextPlan.trim().isNotEmpty) {
      body['next_plan'] = nextPlan.trim();
    }
    await _dio.post('/api/lecturer/schedule/$sessionId/report', data: body);
  }

  // Giữ tương thích với code cũ của bạn:
  // submitReport(id, content: '...', issues: '...', nextPlan: '...')
  @Deprecated('Dùng submitReport({...}) với tham số đặt tên')
  Future<void> submitReportLegacy(
      int id, {
        required String content,
        String? issues,
        String? nextPlan,
      }) async {
    await submitReport(
      sessionId: id,
      content: content,
      issues: issues,
      nextPlan: nextPlan,
    );
  }
}

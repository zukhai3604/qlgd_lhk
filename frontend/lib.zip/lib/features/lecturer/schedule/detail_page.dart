import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher_string.dart';
import 'service.dart';

class LecturerScheduleDetailPage extends StatefulWidget {
  final int sessionId;
  const LecturerScheduleDetailPage({super.key, required this.sessionId});

  @override
  State<LecturerScheduleDetailPage> createState() =>
      _LecturerScheduleDetailPageState();
}

class _LecturerScheduleDetailPageState
    extends State<LecturerScheduleDetailPage> {
  final _svc = LecturerScheduleService();

  bool _loading = true;
  String? _error;

  Map<String, dynamic> _detail = {};
  List<Map<String, dynamic>> _materials = [];

  final TextEditingController _newMaterialCtrl = TextEditingController();
  final TextEditingController _noteCtrl = TextEditingController();
  String _statusValue = 'done'; // done | teaching | canceled

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _newMaterialCtrl.dispose();
    _noteCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final d = await _svc.getDetail(widget.sessionId);
      final m = await _svc.getMaterials(widget.sessionId);

      final rawStatus = (d['status'] ?? '').toString().toLowerCase();
      _statusValue = switch (rawStatus) {
        'done' || 'đã hoàn thành' => 'done',
        'teaching' || 'đang dạy' => 'teaching',
        'canceled' || 'cancelled' || 'hủy' => 'canceled',
        _ => 'done',
      };

      _detail = d;
      _materials = m;

      final note = (d['note'] ?? '').toString();
      if (note.isNotEmpty) _noteCtrl.text = note;
    } catch (e) {
      _error = '$e';
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  String _hhmm(dynamic s) {
    final str = (s ?? '').toString();
    return str.length >= 5 ? str.substring(0, 5) : str;
  }

  String _fmtDate(String? iso) {
    if (iso == null || iso.isEmpty) return '';
    final p = iso.split('-');
    return p.length == 3 ? '${p[2]}/${p[1]}/${p[0]}' : iso;
  }

  Future<void> _addMaterial() async {
    final title = _newMaterialCtrl.text.trim();
    if (title.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Nhập nội dung bài học trước đã')),
      );
      return;
    }
    await _svc.addMaterial(widget.sessionId, title);
    _newMaterialCtrl.clear();
    final m = await _svc.getMaterials(widget.sessionId);
    if (!mounted) return;
    setState(() => _materials = m);
  }

  Future<void> _saveReport() async {
    await _svc.submitReport(
      sessionId: widget.sessionId,
      status: _statusValue, // map server nếu cần tại service/controller
      note: _noteCtrl.text,
    );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Đã lưu báo cáo buổi học')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    if (_loading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }
    if (_error != null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Chi tiết buổi học')),
        body: Center(
          child: Text(
            'Không tải được dữ liệu.\n$_error',
            textAlign: TextAlign.center,
            style: const TextStyle(color: Colors.red),
          ),
        ),
      );
    }

    final subject = (_detail['subject'] ?? '').toString();
    final className = (_detail['class_name'] ?? '').toString();
    final date = _fmtDate((_detail['date'] ?? '').toString());
    final start = _hhmm(_detail['start_time'] ?? _detail['start']);
    final end = _hhmm(_detail['end_time'] ?? _detail['end']);
    final room = (_detail['room'] ?? '').toString();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Chi tiết buổi học'),
        leading: const BackButton(),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: RefreshIndicator(
                onRefresh: _load,
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
                  children: [
                    Center(
                      child: Text(
                        'TRƯỜNG ĐẠI HỌC THỦY LỢI',
                        style: theme.textTheme.labelLarge?.copyWith(
                          color: theme.colorScheme.primary,
                          fontWeight: FontWeight.w700,
                          letterSpacing: .2,
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Chi tiết buổi học',
                      style: theme.textTheme.headlineSmall
                          ?.copyWith(fontWeight: FontWeight.w800),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '$subject - $className',
                      style: theme.textTheme.titleMedium
                          ?.copyWith(fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton.icon(
                        onPressed: () {
                          // TODO: điều hướng sang màn điểm danh (attendance)
                        },
                        icon: const Icon(Icons.playlist_add_check),
                        label: const Text('Điểm danh sinh viên'),
                      ),
                    ),
                    const SizedBox(height: 16),
                    _kv('Ca', '$start - $end'),
                    _kv('Ngày', date),
                    _kv('Phòng', room.isEmpty ? '-' : room),
                    const SizedBox(height: 12),

                    Text(
                      'Nội dung bài học',
                      style: theme.textTheme.titleMedium
                          ?.copyWith(fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(height: 8),

                    if (_materials.isEmpty)
                      _materialTile(theme,
                          title: 'Chưa có nội dung', disabled: true)
                    else
                      ..._materials.map(
                            (m) => _materialTile(
                          theme,
                          title: (m['title'] ?? '').toString(),
                          subtitle:
                          (m['uploaded_at'] ?? '').toString(), // nếu có
                          url: (m['file_url'] ?? '').toString(),
                        ),
                      ),

                    const SizedBox(height: 8),

                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _newMaterialCtrl,
                            decoration: InputDecoration(
                              prefixIcon: const Icon(Icons.add),
                              hintText: 'Thêm nội dung bài học',
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                              contentPadding: const EdgeInsets.symmetric(
                                  horizontal: 12, vertical: 12),
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        FilledButton(
                          onPressed: _addMaterial,
                          child: const Text('Thêm'),
                        ),
                      ],
                    ),

                    const SizedBox(height: 16),

                    DropdownButtonFormField<String>(
                      value: _statusValue,
                      decoration: InputDecoration(
                        labelText: 'Trạng thái giảng dạy',
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12)),
                      ),
                      items: const [
                        DropdownMenuItem(
                            value: 'done', child: Text('Đã hoàn thành')),
                        DropdownMenuItem(
                            value: 'teaching', child: Text('Đang dạy')),
                        DropdownMenuItem(
                            value: 'canceled', child: Text('Hủy buổi')),
                      ],
                      onChanged: (v) =>
                          setState(() => _statusValue = v ?? 'done'),
                    ),

                    const SizedBox(height: 12),

                    TextField(
                      controller: _noteCtrl,
                      maxLines: 4,
                      decoration: InputDecoration(
                        labelText: 'Ghi chú',
                        alignLabelWithHint: true,
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12)),
                      ),
                    ),

                    const SizedBox(height: 80),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              child: SizedBox(
                height: 44,
                width: double.infinity,
                child: FilledButton(
                  onPressed: _saveReport,
                  child: const Text('Lưu'),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _kv(String k, String v) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          SizedBox(
            width: 145,
            child: Text(
              '$k:',
              style: const TextStyle(fontWeight: FontWeight.w700),
            ),
          ),
          Expanded(child: Text(v)),
        ],
      ),
    );
  }

  Widget _materialTile(
      ThemeData theme, {
        required String title,
        String? subtitle,
        String? url,
        bool disabled = false,
      }) {
    final hasUrl = (url ?? '').isNotEmpty;
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: theme.dividerColor),
      ),
      child: ListTile(
        enabled: !disabled,
        leading: const Icon(Icons.description_outlined),
        title: Text(title),
        subtitle: (subtitle != null && subtitle.isNotEmpty)
            ? Text(subtitle)
            : null,
        trailing: hasUrl ? const Icon(Icons.open_in_new) : null,
        onTap: hasUrl ? () => launchUrlString(url!) : null,
        dense: true,
      ),
    );
  }
}

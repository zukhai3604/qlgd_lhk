import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart'; // Mở import này để dùng điều hướng chuẩn
import 'service.dart';
import 'detail_page.dart';
 // Đảm bảo đường dẫn đúng

class LecturerWeekPage extends StatefulWidget {
  const LecturerWeekPage({super.key});

  @override
  State<LecturerWeekPage> createState() => _LecturerWeekPageState();
}

class _LecturerWeekPageState extends State<LecturerWeekPage> {
  final _svc = LecturerScheduleService();
  bool loading = true;
  String? error;
  Map<String, dynamic> range = {};
  List<Map<String, dynamic>> items = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    if (!mounted) return;
    setState(() {
      loading = true;
      error = null;
    });
    try {
      final res = await _svc.getWeek();
      range = Map<String, dynamic>.from(res['range'] ?? {});
      items = (res['data'] as List)
          .cast<Map>()
          .map((e) => Map<String, dynamic>.from(e))
          .toList();
    } catch (e) {
      if (mounted) setState(() => error = 'Không thể tải lịch tuần: $e');
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Color _statusColor(String? s, BuildContext ctx) {
    final cs = Theme.of(ctx).colorScheme;
    switch ((s ?? '').toUpperCase()) {
      case 'TEACHING':
        return cs.primary;
      case 'DONE':
        return Colors.green;
      case 'CANCELED':
        return Colors.red;
      case 'MAKEUP_PLANNED':
        return Colors.orange;
      case 'MAKEUP_DONE':
        return Colors.teal;
      default:
        return cs.secondary;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Lịch giảng dạy theo tuần'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(22),
          child: loading
              ? const SizedBox.shrink()
              : Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Text(
                    '${range['from'] ?? ''} → ${range['to'] ?? ''}',
                    style: const TextStyle(fontSize: 12),
                  ),
                ),
        ),
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (loading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(error!, style: const TextStyle(color: Colors.red), textAlign: TextAlign.center),
              const SizedBox(height: 8),
              FilledButton.icon(
                onPressed: _load,
                icon: const Icon(Icons.refresh),
                label: const Text('Tải lại'),
              )
            ],
          ),
        ),
      );
    }

    if (items.isEmpty) {
      return RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          children: const [
            SizedBox(height: 120),
            Center(child: Text('Tuần này không có buổi học nào.')),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _load,
      child: ListView.separated(
        padding: const EdgeInsets.all(12),
        itemCount: items.length,
        separatorBuilder: (_, __) => const SizedBox(height: 8),
        itemBuilder: (_, i) {
          final it = items[i];
          final status = (it['status'] ?? '').toString();

          return Card(
            elevation: 1,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
              side: BorderSide(color: Colors.grey.withOpacity(0.2)),
            ),
            child: ListTile(
              title: Text(
                '${it['subject'] ?? 'Môn học'} - ${it['class_name'] ?? 'Lớp'}',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Text(
                '${it['date']} | ${it['start_time'] ?? '--:--'}–${it['end_time'] ?? '--:--'}  •  P.${it['room'] ?? '-'}',
              ),
              trailing: Chip(
                label: Text(status.toUpperCase(), style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold)),
                backgroundColor: _statusColor(status, context).withOpacity(.15),
                side: BorderSide.none,
                visualDensity: VisualDensity.compact,
              ),
              onTap: () {
                // CÁCH 1: Dùng GoRouter (khuyến khích và đã chuẩn hóa)
                final sessionId = it['id'] as int?;
                if (sessionId != null) {
                  context.push('/schedule/$sessionId');
                }

                // CÁCH 2: Dùng Navigator.push (đã sửa lỗi cú pháp)
                // Navigator.of(context).push(
                //   MaterialPageRoute(
                //     builder: (_) => LecturerScheduleDetailPage(
                //       sessionId: it['id'] as int,
                //     ),
                //   ),
                // );
              },
            ),
          );
        },
      ),
    );
  }
}

// lib/shared/providers.dart
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:dio/dio.dart';

import '../core/network/dio_client.dart';
import '../core/storage/token_storage.dart';

/// ==== AUTH (tối giản để đăng nhập) ====
abstract class AuthRepository {
  Future<void> login({required String email, required String password});
}

class AuthApi {
  final Dio _dio;
  AuthApi(this._dio);

  Future<Response> login(String email, String password) {
    return _dio.post(
      '/auth/login',
      data: {'email': email, 'password': password},
    );
  }
}

class AuthRepositoryImpl implements AuthRepository {
  final AuthApi api;
  final TokenStorage storage;

  AuthRepositoryImpl(this.api, this.storage);

  @override
  Future<void> login({required String email, required String password}) async {
    final res = await api.login(email, password);
    final data = res.data as Map<String, dynamic>;

    // tuỳ backend: access_token hoặc token
    final access = (data['access_token'] ?? data['token'])?.toString();
    if (access != null && access.isNotEmpty) {
      await storage.setAccessToken(access);
    } else {
      throw Exception('Không nhận được access_token từ backend');
    }
  }
}

/// ==== Providers chung ====
/// Lưu/đọc token tập trung
final tokenStorageProvider = Provider<TokenStorage>((ref) => TokenStorage());

/// HTTP client dùng chung
final dioProvider = Provider<Dio>((ref) => buildDio()); // <-- đã sửa (KHÔNG dùng Reader)

/// Auth providers
final authApiProvider  = Provider<AuthApi>((ref) => AuthApi(ref.read(dioProvider)));
final authRepoProvider = Provider<AuthRepository>((ref) =>
    AuthRepositoryImpl(ref.read(authApiProvider), ref.read(tokenStorageProvider)));

<?php
use OpenApi\Annotations as OA;

/**
 * @OA\Info(
 *   title="QLGD_LHK API",
 *   version="1.0.0",
 *   description="Tài liệu API hệ thống Quản lý Lịch giảng dạy"
 * )
 * @OA\Server(
 *   url=L5_SWAGGER_CONST_HOST,
 *   description="Local (Laradock Nginx 8888)"
 * )
 * @OA\SecurityScheme(
 *   securityScheme="bearerAuth",
 *   type="http",
 *   scheme="bearer",
 *   bearerFormat="JWT",
 *   description="Use: Bearer {token}"
 * )
 */
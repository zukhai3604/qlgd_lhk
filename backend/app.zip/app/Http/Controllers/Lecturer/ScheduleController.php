<?php
namespace App\Http\Controllers\Lecturer;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use OpenApi\Annotations as OA;

/** @OA\Tag(name="Lecturer - Schedule", description="Lịch dạy") */
class ScheduleController extends Controller
{
    /** @OA\Get(
     *  path="/api/lecturer/schedule/week", tags={"Lecturer - Schedule"}, summary="Lịch dạy theo tuần",
     *  security={{"bearerAuth":{}}},
     *  @OA\Parameter(name="date", in="query", required=false, @OA\Schema(type="string", format="date")),
     *  @OA\Response(response=200, description="OK")
     * ) */
    public function getWeekSchedule(Request $request)
    {
        // Logic lấy lịch tuần
    }

    /** @OA\Get(
     *  path="/api/lecturer/schedule/{id}", tags={"Lecturer - Schedule"}, summary="Chi tiết buổi học",
     *  security={{"bearerAuth":{}}},
     *  @OA\Parameter(name="id", in="path", required=true, @OA\Schema(type="integer")),
     *  @OA\Response(response=200, description="OK"),
     *  @OA\Response(response=404, description="Not Found", @OA\JsonContent(ref="#/components/schemas/Error"))
     * ) */
    public function show($id)
    {
        // Logic lấy chi tiết buổi học
    }
}

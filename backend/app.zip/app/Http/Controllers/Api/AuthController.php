<?php
namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use OpenApi\Annotations as OA;

/** @OA\Tag(name="Auth", description="Xác thực người dùng") */
class AuthController extends Controller
{
    /** @OA\Post(
     *  path="/api/login", tags={"Auth"}, summary="Đăng nhập lấy token",
     *  @OA\RequestBody(required=true, @OA\JsonContent(
     *    required={"email","password"},
     *    @OA\Property(property="email", type="string", format="email"),
     *    @OA\Property(property="password", type="string", format="password")
     *  )),
     *  @OA\Response(response=200, description="OK",
     *    @OA\JsonContent(
     *      @OA\Property(property="token", type="string"),
     *      @OA\Property(property="user", ref="#/components/schemas/User")
     *    )
     *  ),
     *  @OA\Response(response=401, description="Unauthorized", @OA\JsonContent(ref="#/components/schemas/Error"))
     * ) */
    public function login(Request $request)
    {
        // Logic đăng nhập của bạn
    }

    /** @OA\Get(
     *  path="/api/me", tags={"Auth"}, summary="Thông tin người dùng hiện tại",
     *  security={{"bearerAuth":{}}},
     *  @OA\Response(response=200, description="OK", @OA\JsonContent(ref="#/components/schemas/User")),
     *  @OA\Response(response=401, description="Unauthorized", @OA\JsonContent(ref="#/components/schemas/Error"))
     * ) */
    public function me(Request $request)
    {
        return $request->user();
    }

    /** @OA\Post(
     *  path="/api/logout", tags={"Auth"}, summary="Đăng xuất",
     *  security={{"bearerAuth":{}}},
     *  @OA\Response(response=204, description="No Content"),
     *  @OA\Response(response=401, description="Unauthorized", @OA\JsonContent(ref="#/components/schemas/Error"))
     * ) */
    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();
        return response()->noContent();
    }
}
